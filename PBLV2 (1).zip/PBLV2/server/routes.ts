import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { sendEmail } from "./utils/email";
import { insertDeviceSchema, insertBookingSchema, Device } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Device routes
  app.get("/api/devices", async (req, res) => {
    try {
      const devices = await storage.getDevices();
      res.json(devices);
    } catch (error) {
      console.error('Error fetching devices:', error);
      res.status(500).json({ error: "Failed to fetch devices" });
    }
  });
  
  app.get("/api/devices/:id", async (req, res) => {
    try {
      const device = await storage.getDevice(parseInt(req.params.id));
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }
      res.json(device);
    } catch (error) {
      console.error('Error fetching device by ID:', error);
      res.status(500).json({ error: "Failed to fetch device details" });
    }
  });
  
  // Get all bookings for a specific device (both confirmed and pending)
  app.get("/api/devices/:id/bookings", async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      const device = await storage.getDevice(deviceId);
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }
      
      // Get all confirmed and pending bookings for this device
      const bookings = await storage.getDeviceBookings(deviceId, ["confirmed", "pending"]);
      res.json(bookings);
    } catch (error: any) {
      console.error('Error fetching device bookings:', error);
      res.status(500).json({ 
        error: "Failed to fetch device bookings",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.post("/api/devices", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "vendor") {
      return res.status(403).json({ error: "Only vendors can create devices" });
    }

    console.log("Request body:", JSON.stringify(req.body, null, 2));
    
    const parsed = insertDeviceSchema.safeParse(req.body);
    if (!parsed.success) {
      console.log("Validation error:", parsed.error);
      return res.status(400).json(parsed.error);
    }
    
    console.log("Parsed data:", JSON.stringify(parsed.data, null, 2));

    try {
      // Extract the standard fields from the parsed data
      const { 
        name, description, category, pricePerDay, 
        quantity, city, condition, images 
      } = parsed.data;

      // Prepare the device data for storage
      const deviceData = {
        name,
        description,
        category,
        pricePerDay,
        quantity,
        city,
        condition,
        images,
        vendorId: req.user.id,
        // Include optional new fields if they exist in the request body
        brand: req.body.brand,
        model: req.body.model,
        // Convert specifications array to string array if it exists
        specifications: req.body.specifications ? 
          (Array.isArray(req.body.specifications) ? req.body.specifications : [req.body.specifications]) 
          : undefined
      };
      
      console.log("Device data to save:", JSON.stringify(deviceData, null, 2));
      
      const device = await storage.createDevice(deviceData);
      res.status(201).json(device);
    } catch (error) {
      console.error('Error creating device:', error);
      res.status(500).json({ error: "Failed to create device" });
    }
  });
  
  // Update an existing device
  app.put("/api/devices/:id", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "vendor") {
      return res.status(403).json({ error: "Only vendors can update devices" });
    }
    
    const deviceId = parseInt(req.params.id);
    if (isNaN(deviceId)) {
      return res.status(400).json({ error: "Invalid device ID" });
    }
    
    try {
      // First, check if the device exists and belongs to the vendor
      const existingDevice = await storage.getDevice(deviceId);
      if (!existingDevice) {
        return res.status(404).json({ error: "Device not found" });
      }
      
      if (existingDevice.vendorId !== req.user.id) {
        return res.status(403).json({ error: "You do not have permission to update this device" });
      }
      
      // For update operations, we don't strictly validate using zod schema
      // as we want to allow partial updates
      const updateData: Partial<Device> = {
        name: req.body.name,
        description: req.body.description,
        brand: req.body.brand,
        model: req.body.model,
        category: req.body.category,
        pricePerDay: req.body.pricePerDay,
        quantity: req.body.quantity,
        city: req.body.city,
        condition: req.body.condition,
        images: req.body.images,
        // Vendors cannot update device availability
      };
      
      // Handle specifications specially since they might need processing
      if (req.body.specifications) {
        updateData.specifications = Array.isArray(req.body.specifications) 
          ? req.body.specifications 
          : [req.body.specifications];
      }
      
      // Remove undefined fields
      Object.keys(updateData).forEach(key => {
        if (updateData[key as keyof typeof updateData] === undefined) {
          delete updateData[key as keyof typeof updateData];
        }
      });
      
      console.log("Updating device with data:", JSON.stringify(updateData, null, 2));
      
      const updatedDevice = await storage.updateDevice(deviceId, updateData);
      res.json(updatedDevice);
    } catch (error) {
      console.error('Error updating device:', error);
      res.status(500).json({ error: "Failed to update device" });
    }
  });

  // Booking routes
  app.post("/api/bookings", async (req, res) => {
    if (!req.isAuthenticated() || req.user.role !== "organizer") {
      return res.status(403).json({ error: "Only organizers can create bookings" });
    }

    const parsed = insertBookingSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json(parsed.error);

    try {
      const device = await storage.getDevice(parsed.data.deviceId);
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }

      if (!device.available) {
        return res.status(400).json({ error: "Device is unavailable for booking" });
      }

      // Validate dates
      const startDate = new Date(parsed.data.startDate);
      const endDate = new Date(parsed.data.endDate);
      
      // Check if dates are valid
      if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return res.status(400).json({ error: "Invalid date format" });
      }
      
      // Check if start date is before end date
      if (startDate >= endDate) {
        return res.status(400).json({ error: "Start date must be before end date" });
      }
      
      // Check if start date is in the future
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (startDate < today) {
        return res.status(400).json({ error: "Start date must be today or in the future" });
      }

      // Check for device availability using our new method
      const { isAvailable, availableQuantity, totalQuantity } = await storage.checkDeviceAvailability(
        parsed.data.deviceId,
        startDate,
        endDate,
        1 // Request 1 unit for now
      );

      if (!isAvailable) {
        return res.status(400).json({ 
          error: "Device unavailable", 
          message: `Device is not available for the requested dates. Available units: ${availableQuantity}/${totalQuantity}` 
        });
      }

      const vendor = await storage.getUser(device.vendorId);
      if (!vendor) {
        return res.status(404).json({ error: "Vendor not found" });
      }

      try {
        const booking = await storage.createBooking({
          ...parsed.data,
          organizerId: req.user.id,
          status: "pending",
        });
        
        // Send email notification
        await sendEmail({
          to: vendor.email,
          subject: "New Booking Request",
          text: `You have a new booking request for ${device.name} from ${startDate.toLocaleDateString()} to ${endDate.toLocaleDateString()}`,
        });
        
        res.status(201).json(booking);
      } catch (error: any) {
        // Check if it's an availability error (could happen due to race condition)
        if (error.message && 
            (typeof error.message === 'string') && 
            (error.message.includes("Device is not available") || 
             error.message.includes("Device is no longer available"))) {
          return res.status(409).json({ 
            error: "Booking conflict", 
            message: error.message 
          });
        }
        throw error; // Re-throw other errors to be caught by the outer catch
      }
    } catch (error: any) {
      console.error('Error creating booking:', error);
      res.status(500).json({ 
        error: "Failed to create booking", 
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.get("/api/bookings", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ error: "Authentication required" });
    }

    try {
      const bookings = req.user.role === "vendor"
        ? await storage.getVendorBookings(req.user.id)
        : await storage.getOrganizerBookings(req.user.id);
      res.json(bookings);
    } catch (error: any) {
      console.error('Error fetching bookings:', error);
      res.status(500).json({ 
        error: "Failed to fetch bookings",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  // Get organizer details for a booking
  app.get("/api/users/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(403).json({ error: "Authentication required" });
    }

    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Return only safe user data (no password)
      const safeUser = {
        id: user.id,
        username: user.username,
        role: user.role,
        email: user.email,
        name: user.name,
        phone: user.phone
      };
      
      res.json(safeUser);
    } catch (error: any) {
      console.error('Error fetching user details:', error);
      res.status(500).json({ 
        error: "Failed to fetch user details",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  app.patch("/api/bookings/:id/status", async (req, res) => {
    try {
      if (!req.isAuthenticated() || req.user.role !== "vendor") {
        return res.status(403).json({ error: "Only vendors can update booking status" });
      }

      const { status } = req.body;
      if (!["confirmed", "cancelled"].includes(status)) {
        return res.status(400).json({ error: "Invalid status" });
      }

      const booking = await storage.updateBookingStatus(
        parseInt(req.params.id),
        status as "confirmed" | "cancelled"
      );

      if (!booking) {
        return res.status(404).json({ error: "Booking not found" });
      }

      const organizer = await storage.getUser(booking.organizerId);
      if (!organizer) {
        return res.status(404).json({ error: "Organizer not found" });
      }

      await sendEmail({
        to: organizer.email,
        subject: `Booking ${status}`,
        text: `Your booking has been ${status}`,
      });

      // Return the updated booking as JSON
      return res.json(booking);
    } catch (error: any) {
      console.error('Error updating booking status:', error);
      return res.status(500).json({
        error: "Failed to update booking status",
        details: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  // Admin middleware for checking admin role
  function isAdmin(req: Request, res: Response, next: NextFunction) {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ error: "Authentication required" });
    }
    
    if (req.user.role !== "admin") {
      return res.status(403).json({ error: "Admin access required" });
    }
    
    next();
  }
  
  // Admin routes
  app.get("/api/admin/statistics", isAdmin, async (req, res) => {
    try {
      const statistics = await storage.getAdminStatistics();
      res.json(statistics);
    } catch (error: any) {
      console.error('Error fetching admin statistics:', error);
      res.status(500).json({ 
        error: "Failed to fetch statistics",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.get("/api/admin/users", isAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      
      // Filter out sensitive information (passwords)
      const safeUsers = users.map(user => ({
        id: user.id,
        username: user.username,
        role: user.role,
        email: user.email,
        name: user.name,
        phone: user.phone,
        isApproved: user.isApproved
      }));
      
      res.json(safeUsers);
    } catch (error: any) {
      console.error('Error fetching all users:', error);
      res.status(500).json({ 
        error: "Failed to fetch users",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.get("/api/admin/vendors/pending", isAdmin, async (req, res) => {
    try {
      const pendingVendors = await storage.getPendingVendors();
      
      // Filter out sensitive information (passwords)
      const safeVendors = pendingVendors.map(vendor => ({
        id: vendor.id,
        username: vendor.username,
        email: vendor.email,
        name: vendor.name,
        phone: vendor.phone,
        isApproved: vendor.isApproved
      }));
      
      res.json(safeVendors);
    } catch (error: any) {
      console.error('Error fetching pending vendors:', error);
      res.status(500).json({ 
        error: "Failed to fetch pending vendors",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.post("/api/admin/vendors/:id/approve", isAdmin, async (req, res) => {
    try {
      const vendorId = parseInt(req.params.id);
      const vendor = await storage.approveVendor(vendorId);
      
      await sendEmail({
        to: vendor.email,
        subject: "Vendor Account Approved",
        text: "Your vendor account has been approved. You can now list your BMD devices on our platform."
      });
      
      res.json({ success: true, vendor: {
        id: vendor.id,
        username: vendor.username,
        email: vendor.email,
        name: vendor.name,
        isApproved: vendor.isApproved
      }});
    } catch (error: any) {
      console.error('Error approving vendor:', error);
      res.status(500).json({ 
        error: "Failed to approve vendor",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.post("/api/admin/vendors/:id/reject", isAdmin, async (req, res) => {
    try {
      const vendorId = parseInt(req.params.id);
      const vendor = await storage.getUser(vendorId);
      
      if (!vendor || vendor.role !== "vendor") {
        return res.status(404).json({ error: "Vendor not found" });
      }
      
      await storage.rejectVendor(vendorId);
      
      // Send email notification
      await sendEmail({
        to: vendor.email,
        subject: "Vendor Application Rejected",
        text: "We regret to inform you that your vendor application has been rejected. Please contact our support team for more information."
      });
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error rejecting vendor:', error);
      res.status(500).json({ 
        error: "Failed to reject vendor",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.get("/api/admin/devices/pending", isAdmin, async (req, res) => {
    try {
      const pendingDevices = await storage.getPendingDevices();
      res.json(pendingDevices);
    } catch (error: any) {
      console.error('Error fetching pending devices:', error);
      res.status(500).json({ 
        error: "Failed to fetch pending devices",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.post("/api/admin/devices/:id/approve", isAdmin, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      const device = await storage.approveDevice(deviceId);
      
      // Get vendor details to send notification
      const vendor = await storage.getUser(device.vendorId);
      if (vendor) {
        await sendEmail({
          to: vendor.email,
          subject: "Device Listing Approved",
          text: `Your device listing for "${device.name}" has been approved and is now visible to organizers.`
        });
      }
      
      res.json({ success: true, device });
    } catch (error: any) {
      console.error('Error approving device:', error);
      res.status(500).json({ 
        error: "Failed to approve device",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.post("/api/admin/devices/:id/reject", isAdmin, async (req, res) => {
    try {
      const deviceId = parseInt(req.params.id);
      const device = await storage.getDevice(deviceId);
      
      if (!device) {
        return res.status(404).json({ error: "Device not found" });
      }
      
      // Get vendor details to send notification
      const vendor = await storage.getUser(device.vendorId);
      
      await storage.rejectDevice(deviceId);
      
      if (vendor) {
        await sendEmail({
          to: vendor.email,
          subject: "Device Listing Rejected",
          text: `Your device listing for "${device.name}" has been rejected. Please contact our support team for more information.`
        });
      }
      
      res.json({ success: true });
    } catch (error: any) {
      console.error('Error rejecting device:', error);
      res.status(500).json({ 
        error: "Failed to reject device",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.get("/api/admin/bookings", isAdmin, async (req, res) => {
    try {
      const bookings = await storage.getAllBookings();
      res.json(bookings);
    } catch (error: any) {
      console.error('Error fetching all bookings:', error);
      res.status(500).json({ 
        error: "Failed to fetch bookings",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });
  
  app.post("/api/admin/bookings/:id/cancel", isAdmin, async (req, res) => {
    try {
      const bookingId = parseInt(req.params.id);
      const { reason } = req.body;
      
      if (!reason) {
        return res.status(400).json({ error: "Cancellation reason is required" });
      }
      
      const booking = await storage.cancelBookingByAdmin(bookingId, reason);
      
      // Notify both organizer and vendor
      const organizer = await storage.getUser(booking.organizerId);
      if (organizer) {
        await sendEmail({
          to: organizer.email,
          subject: "Booking Cancelled by Admin",
          text: `Your booking has been cancelled by the administrator. Reason: ${reason}`
        });
      }
      
      const device = await storage.getDevice(booking.deviceId);
      if (device) {
        const vendor = await storage.getUser(device.vendorId);
        if (vendor) {
          await sendEmail({
            to: vendor.email,
            subject: "Booking Cancelled by Admin",
            text: `A booking for your device "${device.name}" has been cancelled by the administrator. Reason: ${reason}`
          });
        }
      }
      
      res.json({ success: true, booking });
    } catch (error: any) {
      console.error('Error cancelling booking by admin:', error);
      res.status(500).json({ 
        error: "Failed to cancel booking",
        message: error instanceof Error ? error.message : 'Unknown error'
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}