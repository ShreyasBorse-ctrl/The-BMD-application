import nodemailer from "nodemailer";

const transporter = process.env.EMAIL_USER && process.env.EMAIL_PASSWORD
  ? nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASSWORD,
      },
    })
  : null;

interface EmailParams {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

export async function sendEmail(params: EmailParams) {
  if (!transporter) {
    console.warn("Email functionality is disabled: missing EMAIL_USER or EMAIL_PASSWORD environment variables");
    return false;
  }

  try {
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      ...params,
    });
    return true;
  } catch (error) {
    console.error("Email sending failed:", error);
    return false;
  }
}