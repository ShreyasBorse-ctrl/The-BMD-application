import { users, type User, type InsertUser, devices, type Device, bookings, type Booking, type InsertBooking, type InsertDevice } from "@shared/schema";
import { db } from "./db";
import { eq, and, or, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Device operations
  getDevices(): Promise<Device[]>;
  getDevice(id: number): Promise<Device | undefined>;
  createDevice(device: InsertDevice & { vendorId: number }): Promise<Device>;
  updateDevice(id: number, device: Partial<Device>): Promise<Device>;
  deleteDevice(id: number): Promise<void>;

  // Booking operations
  checkDeviceAvailability(deviceId: number, startDate: Date, endDate: Date, requestedQuantity?: number): Promise<{ 
    isAvailable: boolean,
    availableQuantity: number,
    totalQuantity: number,
    overlappingBookings: Booking[] 
  }>;
  createBooking(booking: InsertBooking & { organizerId: number, status: "pending" | "confirmed" | "cancelled" }): Promise<Booking>;
  getVendorBookings(vendorId: number): Promise<Booking[]>;
  getOrganizerBookings(organizerId: number): Promise<Booking[]>;
  updateBookingStatus(id: number, status: "confirmed" | "cancelled"): Promise<Booking>;
  getDeviceBookings(deviceId: number, includeStatuses?: string[]): Promise<Booking[]>;

  // Admin operations
  getAllUsers(): Promise<User[]>; 
  getPendingVendors(): Promise<User[]>;
  approveVendor(id: number): Promise<User>;
  rejectVendor(id: number): Promise<void>;
  getPendingDevices(): Promise<Device[]>;
  approveDevice(id: number): Promise<Device>;
  rejectDevice(id: number): Promise<void>;
  getAllBookings(): Promise<Booking[]>;
  cancelBookingByAdmin(id: number, reason: string): Promise<Booking>;
  getAdminStatistics(): Promise<{
    totalVendors: number,
    totalOrganizers: number,
    pendingVendors: number,
    pendingDevices: number,
    activeBookings: number,
    totalDevices: number
  }>;

  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool: pool as any,
      createTableIfMissing: true,
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, id));
      return user;
    } catch (error) {
      console.error('Error fetching user by ID:', error);
      throw error;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.username, username));
      return user;
    } catch (error) {
      console.error('Error fetching user by username:', error);
      throw error;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const [user] = await db
        .insert(users)
        .values(insertUser)
        .returning();
      return user;
    } catch (error) {
      console.error('Error creating user:', error);
      throw error;
    }
  }

  // Device operations
  async getDevices(): Promise<Device[]> {
    try {
      // Include all columns including brand, model, and specifications
      const result = await db.execute(sql`
        SELECT 
          id, vendor_id as "vendorId", name, brand, model, description, category, 
          price_per_day as "pricePerDay", quantity, city, 
          condition, specifications, images, available
        FROM devices
      `);
      return result.rows as Device[];
    } catch (error) {
      console.error('Error fetching devices:', error);
      throw error;
    }
  }

  async getDevice(id: number): Promise<Device | undefined> {
    try {
      // Include all columns including brand, model, and specifications
      const result = await db.execute(sql`
        SELECT 
          id, vendor_id as "vendorId", name, brand, model, description, category, 
          price_per_day as "pricePerDay", quantity, city, 
          condition, specifications, images, available
        FROM devices
        WHERE id = ${id}
      `);
      
      if (result.rows.length === 0) {
        return undefined;
      }
      
      return result.rows[0] as Device;
    } catch (error) {
      console.error('Error fetching device by ID:', error);
      throw error;
    }
  }

  async createDevice(insertDevice: InsertDevice & { 
    vendorId: number, 
    brand?: string, 
    model?: string,
    specifications?: string[]
  }): Promise<Device> {
    try {
      // Extract all fields including optional ones
      const deviceData = {
        vendor_id: insertDevice.vendorId,
        name: insertDevice.name,
        brand: insertDevice.brand || null,
        model: insertDevice.model || null,
        description: insertDevice.description,
        category: insertDevice.category,
        price_per_day: insertDevice.pricePerDay,
        quantity: insertDevice.quantity,
        city: insertDevice.city,
        condition: insertDevice.condition,
        // Format images array to PostgreSQL array format
        images: Array.isArray(insertDevice.images) ? 
          `{${insertDevice.images.map(img => `"${img.replace(/"/g, '\\"')}"`).join(',')}}` : 
          '{}',
        // Format specifications array if provided
        specifications: Array.isArray(insertDevice.specifications) ?
          `{${insertDevice.specifications.map(spec => `"${spec.replace(/"/g, '\\"')}"`).join(',')}}` :
          '{}',
        available: true // Set default value
      };
      
      console.log("Structured device data:", JSON.stringify(deviceData, null, 2));
      
      // Use SQL to insert with all columns including brand, model and specifications
      const result = await db.execute(sql`
        INSERT INTO devices (
          vendor_id, name, brand, model, description, category, price_per_day, 
          quantity, city, condition, specifications, images, available
        ) VALUES (
          ${deviceData.vendor_id}, ${deviceData.name}, ${deviceData.brand}, ${deviceData.model},
          ${deviceData.description}, ${deviceData.category}, ${deviceData.price_per_day}, 
          ${deviceData.quantity}, ${deviceData.city}, ${deviceData.condition}, 
          ${deviceData.specifications}, ${deviceData.images}, ${deviceData.available}
        )
        RETURNING id, vendor_id as "vendorId", name, brand, model, description, category,
          price_per_day as "pricePerDay", quantity, city, condition, specifications, images, available
      `);
      
      return result.rows[0] as Device;
    } catch (error) {
      console.error('Error creating device:', error);
      throw error;
    }
  }

  async updateDevice(id: number, updateDevice: Partial<Device>): Promise<Device> {
    try {
      // First check if the device exists
      const checkResult = await db.execute(sql`
        SELECT id FROM devices WHERE id = ${id}
      `);
      
      if (checkResult.rows.length === 0) {
        throw new Error('Device not found');
      }
      
      // Check which fields need to be updated
      const updateFields = [];
      const params = [];
      let paramIndex = 1;
      
      if (updateDevice.name !== undefined) {
        updateFields.push(`name = $${paramIndex}`);
        params.push(updateDevice.name);
        paramIndex++;
      }
      
      if (updateDevice.description !== undefined) {
        updateFields.push(`description = $${paramIndex}`);
        params.push(updateDevice.description);
        paramIndex++;
      }
      
      if (updateDevice.category !== undefined) {
        updateFields.push(`category = $${paramIndex}`);
        params.push(updateDevice.category);
        paramIndex++;
      }
      
      if (updateDevice.pricePerDay !== undefined) {
        updateFields.push(`price_per_day = $${paramIndex}`);
        params.push(updateDevice.pricePerDay);
        paramIndex++;
      }
      
      if (updateDevice.quantity !== undefined) {
        updateFields.push(`quantity = $${paramIndex}`);
        params.push(updateDevice.quantity);
        paramIndex++;
      }
      
      if (updateDevice.city !== undefined) {
        updateFields.push(`city = $${paramIndex}`);
        params.push(updateDevice.city);
        paramIndex++;
      }
      
      if (updateDevice.condition !== undefined) {
        updateFields.push(`condition = $${paramIndex}`);
        params.push(updateDevice.condition);
        paramIndex++;
      }
      
      if (updateDevice.images !== undefined) {
        updateFields.push(`images = $${paramIndex}`);
        // Format images array to PostgreSQL array format
        const formattedImages = Array.isArray(updateDevice.images) ? 
          `{${updateDevice.images.map(img => `"${img.replace(/"/g, '\\"')}"`).join(',')}}` : 
          '{}';
        params.push(formattedImages);
        paramIndex++;
      }
      
      if (updateDevice.available !== undefined) {
        updateFields.push(`available = $${paramIndex}`);
        params.push(updateDevice.available);
        paramIndex++;
      }
      
      // Add missing fields if they're in the update object
      if (updateDevice.brand !== undefined) {
        updateFields.push(`brand = $${paramIndex}`);
        params.push(updateDevice.brand);
        paramIndex++;
      }
      
      if (updateDevice.model !== undefined) {
        updateFields.push(`model = $${paramIndex}`);
        params.push(updateDevice.model);
        paramIndex++;
      }
      
      if (updateDevice.specifications !== undefined) {
        updateFields.push(`specifications = $${paramIndex}`);
        // Format specifications array to PostgreSQL array format
        const formattedSpecs = Array.isArray(updateDevice.specifications) ? 
          `{${updateDevice.specifications.map(spec => `"${spec.replace(/"/g, '\\"')}"`).join(',')}}` : 
          '{}';
        params.push(formattedSpecs);
        paramIndex++;
      }
      
      // If no fields to update, just fetch and return the current device
      if (updateFields.length === 0) {
        const result = await db.execute(sql`
          SELECT 
            id, vendor_id as "vendorId", name, brand, model, description, category, 
            price_per_day as "pricePerDay", quantity, city, 
            condition, specifications, images, available
          FROM devices
          WHERE id = ${id}
        `);
        
        return result.rows[0] as Device;
      }
      
      // Use direct SQL with parameters
      const sqlQuery = `
        UPDATE devices
        SET ${updateFields.join(', ')}
        WHERE id = $${paramIndex}
        RETURNING 
          id, vendor_id as "vendorId", name, brand, model, description, category,
          price_per_day as "pricePerDay", quantity, city, condition, 
          specifications, images, available
      `;
      
      // Add the id as the last parameter
      params.push(id);
      
      // Execute the query
      const { rows } = await pool.query(sqlQuery, params);
      
      return rows[0] as Device;
    } catch (error) {
      console.error('Error updating device:', error);
      throw error;
    }
  }

  async deleteDevice(id: number): Promise<void> {
    try {
      await db.execute(sql`
        DELETE FROM devices 
        WHERE id = ${id}
      `);
    } catch (error) {
      console.error('Error deleting device:', error);
      throw error;
    }
  }

  // Booking operations
  async checkDeviceAvailability(deviceId: number, startDate: Date, endDate: Date, requestedQuantity: number = 1): Promise<{ 
    isAvailable: boolean,
    availableQuantity: number,
    totalQuantity: number,
    overlappingBookings: Booking[] 
  }> {
    try {
      // Step 1: Get the device to check its total quantity
      const device = await this.getDevice(deviceId);
      if (!device) {
        throw new Error('Device not found');
      }
      
      const totalQuantity = device.quantity;
      
      // Step 2: Find all overlapping bookings with status 'pending' or 'confirmed'
      // End date is exclusive, so we need to check if endDate >= booking.startDate
      // Start date is inclusive, so we check if startDate < booking.endDate
      const result = await pool.query(`
        SELECT 
          id, device_id as "deviceId", organizer_id as "organizerId",
          start_date as "startDate", end_date as "endDate",
          status, city, quantity
        FROM bookings
        WHERE device_id = $1
          AND status IN ('pending', 'confirmed')
          AND $2::timestamp < end_date
          AND $3::timestamp >= start_date
      `, [deviceId, startDate.toISOString(), endDate.toISOString()]);
      
      const overlappingBookings = result.rows as Booking[];
      
      // Step 3: Calculate the sum of units booked for the overlapping period
      // Use the quantity field from each booking to determine how many units are booked
      const bookedQuantity = overlappingBookings.reduce((sum, booking) => {
        return sum + (booking.quantity || 1); // Default to 1 for any old bookings without a quantity
      }, 0);
      
      // Step 4: Calculate available quantity
      const availableQuantity = Math.max(0, totalQuantity - bookedQuantity);
      
      return {
        isAvailable: availableQuantity >= requestedQuantity,
        availableQuantity,
        totalQuantity,
        overlappingBookings
      };
    } catch (error) {
      console.error('Error checking device availability:', error);
      throw error;
    }
  }
  
  async createBooking(insertBooking: InsertBooking & { organizerId: number, status: "pending" | "confirmed" | "cancelled" }): Promise<Booking> {
    try {
      // Convert string dates to Date objects
      const startDate = new Date(insertBooking.startDate);
      const endDate = new Date(insertBooking.endDate);
      
      // Check availability before booking
      const { isAvailable, availableQuantity, totalQuantity } = await this.checkDeviceAvailability(
        insertBooking.deviceId, 
        startDate,
        endDate
      );
      
      if (!isAvailable) {
        throw new Error(`Device is not available for the requested dates. Available units: ${availableQuantity}/${totalQuantity}`);
      }
      
      // Using a transaction to ensure atomicity
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        
        // Recheck availability within transaction - now with quantity tracking
        // End date is exclusive in our system - a new booking can start on the same day as another's end date
        const availabilityResult = await client.query(`
          SELECT SUM(quantity) as booked_quantity
          FROM bookings
          WHERE device_id = $1
            AND status IN ('pending', 'confirmed')
            AND $2::timestamp < end_date
            AND $3::timestamp >= start_date
        `, [insertBooking.deviceId, startDate.toISOString(), endDate.toISOString()]);
        
        const booked_quantity = parseInt(availabilityResult.rows[0].booked_quantity) || 0;
        
        // Get device quantity
        const deviceResult = await client.query(`
          SELECT quantity
          FROM devices
          WHERE id = $1
        `, [insertBooking.deviceId]);
        
        if (deviceResult.rows.length === 0) {
          throw new Error('Device not found');
        }
        
        const { quantity } = deviceResult.rows[0];
        const requestedQuantity = insertBooking.quantity || 1;
        
        // Check if requested quantity is available
        if (booked_quantity + requestedQuantity > quantity) {
          const availableQuantity = Math.max(0, quantity - booked_quantity);
          throw new Error(`Not enough units available for the requested dates. 
            Available units: ${availableQuantity}/${quantity}, Requested: ${requestedQuantity}`);
        }
        
        // Insert the booking with quantity and camp details
        const bookingResult = await client.query(`
          INSERT INTO bookings (
            device_id, organizer_id, start_date, end_date, status, city, quantity,
            camp_name, camp_address, expected_patients, additional_requirements,
            delivery_date, payment_mode, special_instructions
          ) VALUES (
            $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14
          )
          RETURNING 
            id, device_id as "deviceId", organizer_id as "organizerId",
            start_date as "startDate", end_date as "endDate",
            status, city, quantity, camp_name as "campName", camp_address as "campAddress", 
            expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
            delivery_date as "deliveryDate", payment_mode as "paymentMode", 
            special_instructions as "specialInstructions"
        `, [
          insertBooking.deviceId,
          insertBooking.organizerId,
          startDate.toISOString(),
          endDate.toISOString(),
          insertBooking.status,
          insertBooking.city,
          insertBooking.quantity || 1, // Default to 1 if not specified
          insertBooking.campName || null,
          insertBooking.campAddress || null,
          insertBooking.expectedPatients || null,
          insertBooking.additionalRequirements || null,
          insertBooking.deliveryDate || null,
          insertBooking.paymentMode || null,
          insertBooking.specialInstructions || null
        ]);
        
        await client.query('COMMIT');
        return bookingResult.rows[0] as Booking;
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    } catch (error) {
      console.error('Error creating booking:', error);
      throw error;
    }
  }

  async getVendorBookings(vendorId: number): Promise<Booking[]> {
    try {
      // First get all devices for this vendor
      const devicesResult = await db.execute(sql`
        SELECT id FROM devices WHERE vendor_id = ${vendorId}
      `);
      
      const devicesList = devicesResult.rows as { id: number }[];

      if (devicesList.length === 0) {
        return [];
      }

      // Get the IDs of all devices owned by this vendor
      const deviceIds = devicesList.map(device => device.id);
      
      if (deviceIds.length === 1) {
        // If there's only one device, use a simple equality check
        const bookingsResult = await db.execute(sql`
          SELECT 
            id, device_id as "deviceId", organizer_id as "organizerId",
            start_date as "startDate", end_date as "endDate",
            status, city, quantity,
            camp_name as "campName", camp_address as "campAddress", 
            expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
            delivery_date as "deliveryDate", payment_mode as "paymentMode", 
            special_instructions as "specialInstructions"
          FROM bookings
          WHERE device_id = ${deviceIds[0]}
        `);
        
        return bookingsResult.rows as Booking[];
      } else {
        // If there are multiple devices, use IN operator instead of ANY
        const deviceIdsString = deviceIds.join(',');
        const bookingsResult = await pool.query(`
          SELECT 
            id, device_id as "deviceId", organizer_id as "organizerId",
            start_date as "startDate", end_date as "endDate",
            status, city, quantity,
            camp_name as "campName", camp_address as "campAddress", 
            expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
            delivery_date as "deliveryDate", payment_mode as "paymentMode", 
            special_instructions as "specialInstructions"
          FROM bookings
          WHERE device_id IN (${deviceIdsString})
        `);
        
        return bookingsResult.rows as Booking[];
      }
    } catch (error) {
      console.error('Error fetching vendor bookings:', error);
      throw error;
    }
  }

  async getOrganizerBookings(organizerId: number): Promise<Booking[]> {
    try {
      const result = await db.execute(sql`
        SELECT 
          id, device_id as "deviceId", organizer_id as "organizerId",
          start_date as "startDate", end_date as "endDate",
          status, city, quantity,
          camp_name as "campName", camp_address as "campAddress", 
          expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
          delivery_date as "deliveryDate", payment_mode as "paymentMode", 
          special_instructions as "specialInstructions"
        FROM bookings
        WHERE organizer_id = ${organizerId}
      `);
      
      return result.rows as Booking[];
    } catch (error) {
      console.error('Error fetching organizer bookings:', error);
      throw error;
    }
  }

  async updateBookingStatus(id: number, status: "confirmed" | "cancelled"): Promise<Booking> {
    try {
      const result = await db.execute(sql`
        UPDATE bookings
        SET status = ${status}
        WHERE id = ${id}
        RETURNING 
          id, device_id as "deviceId", organizer_id as "organizerId",
          start_date as "startDate", end_date as "endDate",
          status, city, quantity,
          camp_name as "campName", camp_address as "campAddress", 
          expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
          delivery_date as "deliveryDate", payment_mode as "paymentMode", 
          special_instructions as "specialInstructions"
      `);
      
      if (result.rows.length === 0) {
        throw new Error('Booking not found');
      }
      
      return result.rows[0] as Booking;
    } catch (error) {
      console.error('Error updating booking status:', error);
      throw error;
    }
  }

  async getDeviceBookings(deviceId: number, includeStatuses: string[] = ['confirmed']): Promise<Booking[]> {
    try {
      // Build the status condition based on provided statuses
      let statusCondition = '';
      if (includeStatuses && includeStatuses.length > 0) {
        statusCondition = `AND status IN (${includeStatuses.map(s => `'${s}'`).join(',')})`;
      }
      
      // Using parameterized query with pool
      const result = await pool.query(`
        SELECT 
          id, device_id as "deviceId", organizer_id as "organizerId",
          start_date as "startDate", end_date as "endDate",
          status, city, quantity,
          camp_name as "campName", camp_address as "campAddress", 
          expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
          delivery_date as "deliveryDate", payment_mode as "paymentMode", 
          special_instructions as "specialInstructions"
        FROM bookings
        WHERE device_id = $1 ${statusCondition}
      `, [deviceId]);
      
      return result.rows as Booking[];
    } catch (error) {
      console.error('Error fetching device bookings:', error);
      throw error;
    }
  }

  // Admin operations
  async getAllUsers(): Promise<User[]> {
    try {
      const result = await db.select().from(users);
      return result;
    } catch (error) {
      console.error('Error fetching all users:', error);
      throw error;
    }
  }
  
  async getPendingVendors(): Promise<User[]> {
    try {
      const result = await db.select().from(users).where(
        and(
          eq(users.role, 'vendor'),
          eq(users.isApproved, false)
        )
      );
      return result;
    } catch (error) {
      console.error('Error fetching pending vendors:', error);
      throw error;
    }
  }
  
  async approveVendor(id: number): Promise<User> {
    try {
      const [user] = await db.update(users)
        .set({ isApproved: true })
        .where(and(eq(users.id, id), eq(users.role, 'vendor')))
        .returning();
        
      if (!user) {
        throw new Error('Vendor not found or already approved');
      }
      
      return user;
    } catch (error) {
      console.error('Error approving vendor:', error);
      throw error;
    }
  }
  
  async rejectVendor(id: number): Promise<void> {
    try {
      const result = await db.delete(users)
        .where(and(eq(users.id, id), eq(users.role, 'vendor'), eq(users.isApproved, false)))
        .returning();
        
      if (result.length === 0) {
        throw new Error('Vendor not found or already approved');
      }
    } catch (error) {
      console.error('Error rejecting vendor:', error);
      throw error;
    }
  }
  
  async getPendingDevices(): Promise<Device[]> {
    try {
      const result = await db.execute(sql`
        SELECT 
          id, vendor_id as "vendorId", name, brand, model, description, category, 
          price_per_day as "pricePerDay", quantity, city, 
          condition, specifications, images, available, is_approved as "isApproved"
        FROM devices
        WHERE is_approved = false
      `);
      
      return result.rows as Device[];
    } catch (error) {
      console.error('Error fetching pending devices:', error);
      throw error;
    }
  }
  
  async approveDevice(id: number): Promise<Device> {
    try {
      const result = await pool.query(`
        UPDATE devices 
        SET is_approved = true
        WHERE id = $1 AND is_approved = false
        RETURNING 
          id, vendor_id as "vendorId", name, brand, model, description, category,
          price_per_day as "pricePerDay", quantity, city, condition, 
          specifications, images, available, is_approved as "isApproved"
      `, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Device not found or already approved');
      }
      
      return result.rows[0] as Device;
    } catch (error) {
      console.error('Error approving device:', error);
      throw error;
    }
  }
  
  async rejectDevice(id: number): Promise<void> {
    try {
      const result = await pool.query(`
        DELETE FROM devices
        WHERE id = $1 AND is_approved = false
        RETURNING id
      `, [id]);
      
      if (result.rows.length === 0) {
        throw new Error('Device not found or already approved');
      }
    } catch (error) {
      console.error('Error rejecting device:', error);
      throw error;
    }
  }
  
  async getAllBookings(): Promise<Booking[]> {
    try {
      const result = await pool.query(`
        SELECT 
          id, device_id as "deviceId", organizer_id as "organizerId",
          start_date as "startDate", end_date as "endDate",
          status, city, quantity,
          camp_name as "campName", camp_address as "campAddress", 
          expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
          delivery_date as "deliveryDate", payment_mode as "paymentMode", 
          special_instructions as "specialInstructions"
        FROM bookings
        ORDER BY start_date DESC
      `);
      
      return result.rows as Booking[];
    } catch (error) {
      console.error('Error fetching all bookings:', error);
      throw error;
    }
  }
  
  async cancelBookingByAdmin(id: number, reason: string): Promise<Booking> {
    try {
      const result = await pool.query(`
        UPDATE bookings
        SET status = 'cancelled',
            special_instructions = COALESCE(special_instructions, '') || $2
        WHERE id = $1 AND status IN ('pending', 'confirmed')
        RETURNING 
          id, device_id as "deviceId", organizer_id as "organizerId",
          start_date as "startDate", end_date as "endDate",
          status, city, quantity,
          camp_name as "campName", camp_address as "campAddress", 
          expected_patients as "expectedPatients", additional_requirements as "additionalRequirements",
          delivery_date as "deliveryDate", payment_mode as "paymentMode", 
          special_instructions as "specialInstructions"
      `, [id, `\nCANCELLED BY ADMIN: ${reason}`]);
      
      if (result.rows.length === 0) {
        throw new Error('Booking not found or already cancelled/completed');
      }
      
      return result.rows[0] as Booking;
    } catch (error) {
      console.error('Error cancelling booking by admin:', error);
      throw error;
    }
  }
  
  async getAdminStatistics(): Promise<{
    totalVendors: number,
    totalOrganizers: number,
    pendingVendors: number,
    pendingDevices: number,
    activeBookings: number,
    totalDevices: number
  }> {
    try {
      // Using a transaction to ensure consistent stats
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        
        // Total vendors
        const vendorsResult = await client.query(`
          SELECT COUNT(*) as count FROM users 
          WHERE role = 'vendor' AND is_approved = true
        `);
        
        // Total organizers
        const organizersResult = await client.query(`
          SELECT COUNT(*) as count FROM users 
          WHERE role = 'organizer'
        `);
        
        // Pending vendors
        const pendingVendorsResult = await client.query(`
          SELECT COUNT(*) as count FROM users 
          WHERE role = 'vendor' AND is_approved = false
        `);
        
        // Pending devices
        const pendingDevicesResult = await client.query(`
          SELECT COUNT(*) as count FROM devices 
          WHERE is_approved = false
        `);
        
        // Active bookings (pending or confirmed)
        const activeBookingsResult = await client.query(`
          SELECT COUNT(*) as count FROM bookings 
          WHERE status IN ('pending', 'confirmed')
        `);
        
        // Total devices
        const totalDevicesResult = await client.query(`
          SELECT COUNT(*) as count FROM devices 
          WHERE is_approved = true
        `);
        
        await client.query('COMMIT');
        
        return {
          totalVendors: parseInt(vendorsResult.rows[0].count) || 0,
          totalOrganizers: parseInt(organizersResult.rows[0].count) || 0,
          pendingVendors: parseInt(pendingVendorsResult.rows[0].count) || 0,
          pendingDevices: parseInt(pendingDevicesResult.rows[0].count) || 0,
          activeBookings: parseInt(activeBookingsResult.rows[0].count) || 0,
          totalDevices: parseInt(totalDevicesResult.rows[0].count) || 0
        };
      } catch (error) {
        await client.query('ROLLBACK');
        throw error;
      } finally {
        client.release();
      }
    } catch (error) {
      console.error('Error getting admin statistics:', error);
      throw error;
    }
  }
}

export const storage = new DatabaseStorage();