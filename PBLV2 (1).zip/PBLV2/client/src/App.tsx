/**
 * Root React component
 * Sets up routing, authentication, and global providers
 * Manages application-wide state and navigation
 */

import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./hooks/use-auth";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import HomePage from "@/pages/home-page";
import VendorDashboard from "@/pages/vendor-dashboard";
import OrganizerDashboard from "@/pages/organizer-dashboard";
import AdminDashboard from "@/pages/admin-dashboard";
import DeviceDetailsPage from "@/pages/device-details";
import { ProtectedRoute } from "./lib/protected-route";
import AppLayout from "@/components/AppLayout";

function Router() {
  return (
    <Switch>
      <Route path="/auth" component={AuthPage} />
      <ProtectedRoute path="/" component={HomePage} />
      <ProtectedRoute path="/vendor-dashboard" component={VendorDashboard} />
      <ProtectedRoute path="/organizer-dashboard" component={OrganizerDashboard} />
      <ProtectedRoute path="/admin-dashboard" component={AdminDashboard} allowedRoles={["admin"]} />
      <ProtectedRoute path="/devices/:id" component={DeviceDetailsPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <AppLayout>
          <Router />
        </AppLayout>
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
