import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Device } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { useState } from "react";
import { getQueryFn } from "@/lib/queryClient";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import { AspectRatio } from "@/components/ui/aspect-ratio";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar as CalendarIcon, Edit } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { ColorCodedCalendar } from "@/components/ColorCodedCalendar";
import { BookingRequestForm } from "@/components/BookingRequestForm";
import { DeviceEditForm } from "@/components/device-edit-form";

export default function DeviceDetailsPage({ params }: { params: { id?: string } }) {
  const id = params?.id;
  const { user } = useAuth();
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const { toast } = useToast();
  
  console.log("Device ID from params prop:", id);
  
  const { data: device, isLoading, error } = useQuery<Device>({
    queryKey: [`/api/devices/${id}`],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!id
  });
  
  console.log("Device data:", device);
  console.log("Loading:", isLoading);
  console.log("Error:", error);


  if (isLoading) {
    return <DeviceDetailsSkeleton />;
  }

  if (error || !device) {
    return (
      <div className="container max-w-6xl mx-auto py-12 px-4">
        <Alert variant="destructive">
          <AlertDescription>
            Error loading device details. Please try again later.
            {error && <div className="mt-2 text-xs">{String(error)}</div>}
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const isOrganizer = user?.role === "organizer";
  const isVendorOwner = user?.role === "vendor" && user.id === device.vendorId;
  
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      {/* Breadcrumb Navigation */}
      <div className="text-sm breadcrumbs mb-4">
        <ul className="flex gap-2 text-muted-foreground">
          <li><a href="/">Home</a></li>
          <li><span className="mx-2">/</span></li>
          <li><a href="/">Devices</a></li>
          <li><span className="mx-2">/</span></li>
          <li className="text-foreground font-medium">{device.name}</li>
        </ul>
      </div>
      
      {/* Main content */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        {/* Left column - Images */}
        <div className="lg:col-span-3">
          {device.images && device.images.length > 0 ? (
            <>
              <Carousel className="w-full">
                <CarouselContent>
                  {device.images.map((image, index) => (
                    <CarouselItem key={index}>
                      <AspectRatio ratio={16/9} className="bg-muted overflow-hidden rounded-lg">
                        <img 
                          src={image} 
                          alt={`${device.name} - Image ${index + 1}`} 
                          className="object-cover w-full h-full"
                        />
                      </AspectRatio>
                    </CarouselItem>
                  ))}
                </CarouselContent>
                <div className="flex justify-end gap-2 mt-2">
                  <CarouselPrevious />
                  <CarouselNext />
                </div>
              </Carousel>
              
              <div className="grid grid-cols-4 gap-2 mt-4">
                {device.images.slice(0, 4).map((image, index) => (
                  <div key={index} className="aspect-square rounded-md overflow-hidden">
                    <img 
                      src={image} 
                      alt={`${device.name} - Thumbnail ${index + 1}`} 
                      className="w-full h-full object-cover hover:opacity-80 transition cursor-pointer"
                    />
                  </div>
                ))}
              </div>
            </>
          ) : (
            <AspectRatio ratio={16/9} className="bg-muted overflow-hidden rounded-lg flex items-center justify-center">
              <div className="text-center p-8">
                <p className="text-muted-foreground">No device images available</p>
              </div>
            </AspectRatio>
          )}
        </div>
        
        {/* Right column - Details */}
        <div className="lg:col-span-2">
          <h1 className="text-3xl font-bold tracking-tight">{device.name}</h1>
          
          {/* Brand and Model */}
          {(device.brand || device.model) && (
            <div className="mt-2 text-lg">
              {device.brand && (
                <span className="font-medium">{device.brand}</span>
              )}
              {device.brand && device.model && (
                <span className="mx-1">-</span>
              )}
              {device.model && (
                <span>{device.model}</span>
              )}
            </div>
          )}
          
          <div className="flex items-center gap-2 mt-2">
            <Badge variant="outline" className="text-sm">
              {device.category}
            </Badge>
            <Badge variant="outline" className="text-sm">
              {device.condition}
            </Badge>
          </div>
          
          <div className="mt-4 text-muted-foreground">
            Location: <span className="font-medium text-foreground">{device.city}</span>
          </div>
          
          <div className="mt-6">
            <div className="text-3xl font-bold">₹{device.pricePerDay.toLocaleString()}</div>
            <div className="text-sm text-muted-foreground">per day</div>
          </div>
          
          <div className="mt-4">
            <h3 className="font-medium">Availability</h3>
            <div className="text-sm mt-1">
              {device.available 
                ? <div className="bg-green-100 text-green-800 inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold">Available</div>
                : <Badge variant="destructive">Currently Unavailable</Badge>
              }
              <span className="ml-2 text-muted-foreground">
                ({device.quantity} {device.quantity > 1 ? 'units' : 'unit'} in stock)
              </span>
            </div>
          </div>
          
          {isOrganizer && (
            <div className="mt-6">
              <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" className="w-full">Book this device</Button>
                </DialogTrigger>
                <DialogContent className="max-w-[500px] max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Book {device.name}</DialogTitle>
                  </DialogHeader>
                  <BookingRequestForm 
                    device={device} 
                    onSuccess={() => setBookingDialogOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            </div>
          )}
          
          {isVendorOwner && (
            <div className="mt-6">
              <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="lg" className="w-full" variant="outline">
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Device
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-[800px] max-h-[90vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>Edit {device.name}</DialogTitle>
                  </DialogHeader>
                  <DeviceEditForm 
                    device={device} 
                    onSuccess={() => setEditDialogOpen(false)}
                  />
                </DialogContent>
              </Dialog>
            </div>
          )}
        </div>
      </div>
      
      {/* Tabs Section */}
      <div className="mt-12">
        <Tabs defaultValue="description">
          <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-3 md:grid-cols-3">
            <TabsTrigger value="description">Description</TabsTrigger>
            <TabsTrigger value="specifications">Specifications</TabsTrigger>
            <TabsTrigger value="availability">Availability Calendar</TabsTrigger>
          </TabsList>
          
          <TabsContent value="description" className="mt-6">
            <div className="prose prose-slate max-w-none">
              <h3 className="text-xl font-medium mb-4">About this Device</h3>
              {device.description && (
                <>
                  {device.description.includes('<') ? (
                    <div 
                      className="text-muted-foreground" 
                      dangerouslySetInnerHTML={{ __html: device.description }} 
                    />
                  ) : (
                    <p className="text-muted-foreground">{device.description}</p>
                  )}
                </>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="specifications" className="mt-6">
            <Card>
              <CardContent className="pt-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[180px]">Specification</TableHead>
                      <TableHead>Details</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {device.brand && (
                      <TableRow>
                        <TableCell className="font-medium">Brand</TableCell>
                        <TableCell>{device.brand}</TableCell>
                      </TableRow>
                    )}
                    {device.model && (
                      <TableRow>
                        <TableCell className="font-medium">Model</TableCell>
                        <TableCell>{device.model}</TableCell>
                      </TableRow>
                    )}
                    <TableRow>
                      <TableCell className="font-medium">Category</TableCell>
                      <TableCell>{device.category}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Condition</TableCell>
                      <TableCell>{device.condition}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Price per Day</TableCell>
                      <TableCell>₹{device.pricePerDay.toLocaleString()}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Available Units</TableCell>
                      <TableCell>{device.quantity}</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell className="font-medium">Location</TableCell>
                      <TableCell>{device.city}</TableCell>
                    </TableRow>
                    {/* Custom specifications */}
                    {device.specifications && device.specifications.length > 0 && (
                      <>
                        <TableRow>
                          <TableCell colSpan={2} className="font-semibold text-primary pt-4">
                            Additional Specifications
                          </TableCell>
                        </TableRow>
                        {device.specifications.map((spec, index) => {
                          try {
                            // Try to parse the JSON string
                            const parsedSpec = JSON.parse(spec);
                            
                            // Check if it's our expected format with name and value
                            if (parsedSpec && typeof parsedSpec === 'object' && 'name' in parsedSpec && 'value' in parsedSpec) {
                              return (
                                <TableRow key={index}>
                                  <TableCell className="font-medium">{parsedSpec.name}</TableCell>
                                  <TableCell>{parsedSpec.value}</TableCell>
                                </TableRow>
                              );
                            }
                          } catch (error) {
                            // If JSON parsing fails, try the original approach
                            const parts = spec.split(':');
                            if (parts.length === 2) {
                              return (
                                <TableRow key={index}>
                                  <TableCell className="font-medium">{parts[0].trim()}</TableCell>
                                  <TableCell>{parts[1].trim()}</TableCell>
                                </TableRow>
                              );
                            }
                          }
                          
                          // Fallback if all else fails
                          return (
                            <TableRow key={index}>
                              <TableCell className="font-medium">Spec #{index + 1}</TableCell>
                              <TableCell>{spec}</TableCell>
                            </TableRow>
                          );
                        })}
                      </>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="availability" className="mt-6">
            <p className="text-sm text-muted-foreground mb-4">
              Check the real-time availability of this device on the calendar below.
              Green indicates available dates while red shows fully booked dates.
            </p>
            <ColorCodedCalendar 
              device={device} 
              mode="view"
              isViewOnly={true}
            />
            <p className="text-sm text-muted-foreground mt-4 text-center">
              To book this device, select the "Book this device" button at the top.
            </p>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function DeviceDetailsSkeleton() {
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-3">
          <Skeleton className="w-full aspect-video rounded-lg" />
          <div className="grid grid-cols-4 gap-2 mt-4">
            {Array(4).fill(0).map((_, index) => (
              <Skeleton key={index} className="aspect-square rounded-md" />
            ))}
          </div>
        </div>
        
        <div className="lg:col-span-2">
          <Skeleton className="h-10 w-3/4 mb-4" />
          <div className="flex gap-2">
            <Skeleton className="h-6 w-24" />
            <Skeleton className="h-6 w-24" />
          </div>
          <Skeleton className="h-6 w-1/2 mt-4" />
          <Skeleton className="h-10 w-1/3 mt-6" />
          <Skeleton className="h-6 w-1/2 mt-6" />
          <Skeleton className="h-12 w-full mt-6" />
        </div>
      </div>
      
      <div className="mt-12">
        <Skeleton className="h-10 w-[300px] mb-6" />
        <Skeleton className="h-[200px] w-full rounded-lg" />
      </div>
    </div>
  );
}