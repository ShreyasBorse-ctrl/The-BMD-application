import React from "react";

const TermsAndConditions: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-2xl font-bold mb-6">Terms and Conditions</h1>
      <p className="mb-4">
        Welcome to BMD Camp! These terms and conditions outline the rules and
        regulations for the use of our services.
      </p>

      <h2 className="text-xl font-semibold mt-6">1. Acceptance of Terms</h2>
      <p className="mb-4">
        By using our services, you accept these terms and conditions in full. If
        you disagree with any part of these terms, you must not use our
        services.
      </p>

      <h2 className="text-xl font-semibold mt-6">2. Changes to Terms</h2>
      <p className="mb-4">
        We reserve the right to modify these terms at any time. We will notify
        you of any changes by posting the new terms on this page.
      </p>

      <h2 className="text-xl font-semibold mt-6">3. User Responsibilities</h2>
      <p className="mb-4">
        Users are responsible for maintaining the confidentiality of their
        accounts and passwords and for all activities that occur under their
        accounts.
      </p>

      <h2 className="text-xl font-semibold mt-6">4. Governing Law</h2>
      <p className="mb-4">
        These terms shall be governed by and construed in accordance with the
        laws of India.
      </p>

      <h2 className="text-xl font-semibold mt-6">5. Contact Us</h2>
      <p>
        If you have any questions about these Terms and Conditions, please
        contact us at support@bmdcamp.in.
      </p>
    </div>
  );
};

export default TermsAndConditions;
