import React from "react";

const Contact: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold mb-6">Contact Us</h1>
      <p className="mb-4">
        If you have any questions, suggestions, or need assistance, please fill
        out the form below or reach us at{" "}
        <a href="mailto:support@bmdcamp.in" className="text-blue-500">
          support@bmdcamp.in
        </a>
        .
      </p>

      <form className="space-y-6 mt-6">
        <div>
          <label
            htmlFor="name"
            className="block text-sm font-medium text-gray-700"
          >
            Name
          </label>
          <input
            type="text"
            id="name"
            name="name"
            required
            className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          />
        </div>

        <div>
          <label
            htmlFor="email"
            className="block text-sm font-medium text-gray-700"
          >
            Email
          </label>
          <input
            type="email"
            id="email"
            name="email"
            required
            className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          />
        </div>

        <div>
          <label
            htmlFor="message"
            className="block text-sm font-medium text-gray-700"
          >
            Message
          </label>
          <textarea
            id="message"
            name="message"
            rows={4}
            required
            className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          ></textarea>
        </div>

        <button
          type="submit"
          className="w-full mt-6 bg-primary hover:bg-primary/90 text-white py-2 rounded-md"
        >
          Send Message
        </button>
      </form>
    </div>
  );
};

export default Contact;
