import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Loader2, CheckCircle, XCircle, AlertTriangle, Users, Package, Calendar, PieChart } from 'lucide-react';

type AdminStats = {
  totalVendors: number;
  totalOrganizers: number;
  pendingVendors: number;
  pendingDevices: number;
  activeBookings: number;
  totalDevices: number;
};

type SafeUser = {
  id: number;
  username: string;
  role: string;
  email: string;
  name: string;
  phone: string;
  isApproved: boolean;
};

type Device = {
  id: number;
  vendorId: number;
  name: string;
  brand: string | null;
  model: string | null;
  description: string;
  category: string;
  pricePerDay: number;
  quantity: number;
  city: string;
  condition: string;
  specifications: string[] | null;
  images: string[];
  available: boolean;
  isApproved: boolean;
};

type Booking = {
  id: number;
  deviceId: number;
  organizerId: number;
  startDate: string;
  endDate: string;
  status: "pending" | "confirmed" | "completed" | "cancelled";
  city: string;
  quantity: number;
  campName?: string;
  campAddress?: string;
  expectedPatients?: string;
  additionalRequirements?: string;
  deliveryDate?: string;
  paymentMode?: string;
  specialInstructions?: string;
};

export default function AdminDashboard() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [cancelReason, setCancelReason] = useState('');
  const [selectedBookingId, setSelectedBookingId] = useState<number | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  
  // Stats query
  const statsQuery = useQuery({
    queryKey: ['/api/admin/statistics'],
    refetchInterval: 60000, // Refresh every minute
  });
  
  // Users queries
  const usersQuery = useQuery({
    queryKey: ['/api/admin/users'],
    enabled: activeTab === 'users',
  });
  
  const pendingVendorsQuery = useQuery({
    queryKey: ['/api/admin/vendors/pending'],
    enabled: activeTab === 'vendors',
  });
  
  // Devices queries
  const pendingDevicesQuery = useQuery({
    queryKey: ['/api/admin/devices/pending'],
    enabled: activeTab === 'devices',
  });
  
  // Bookings query
  const bookingsQuery = useQuery({
    queryKey: ['/api/admin/bookings'],
    enabled: activeTab === 'bookings',
  });
  
  // Mutations
  const approveVendorMutation = useMutation({
    mutationFn: async (vendorId: number) => {
      return apiRequest('POST', `/api/admin/vendors/${vendorId}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/vendors/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/statistics'] });
      toast({
        title: "Vendor Approved",
        description: "The vendor has been approved successfully.",
        variant: "default"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve vendor",
        variant: "destructive"
      });
    }
  });
  
  const rejectVendorMutation = useMutation({
    mutationFn: async (vendorId: number) => {
      return apiRequest('POST', `/api/admin/vendors/${vendorId}/reject`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/vendors/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/statistics'] });
      toast({
        title: "Vendor Rejected",
        description: "The vendor has been rejected.",
        variant: "default"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject vendor",
        variant: "destructive"
      });
    }
  });
  
  const approveDeviceMutation = useMutation({
    mutationFn: async (deviceId: number) => {
      return apiRequest('POST', `/api/admin/devices/${deviceId}/approve`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/devices/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/statistics'] });
      toast({
        title: "Device Approved",
        description: "The device has been approved and is now visible to organizers.",
        variant: "default"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve device",
        variant: "destructive"
      });
    }
  });
  
  const rejectDeviceMutation = useMutation({
    mutationFn: async (deviceId: number) => {
      return apiRequest('POST', `/api/admin/devices/${deviceId}/reject`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/devices/pending'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/statistics'] });
      toast({
        title: "Device Rejected",
        description: "The device has been rejected.",
        variant: "default"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject device",
        variant: "destructive"
      });
    }
  });
  
  const cancelBookingMutation = useMutation({
    mutationFn: async ({ bookingId, reason }: { bookingId: number, reason: string }) => {
      return apiRequest('POST', `/api/admin/bookings/${bookingId}/cancel`, { reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/bookings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/statistics'] });
      setDialogOpen(false);
      setCancelReason('');
      setSelectedBookingId(null);
      toast({
        title: "Booking Cancelled",
        description: "The booking has been cancelled.",
        variant: "default"
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to cancel booking",
        variant: "destructive"
      });
    }
  });
  
  const handleCancelBooking = () => {
    if (!selectedBookingId || !cancelReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a reason for cancellation",
        variant: "destructive"
      });
      return;
    }
    
    cancelBookingMutation.mutate({ 
      bookingId: selectedBookingId, 
      reason: cancelReason 
    });
  };
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case 'confirmed':
        return <Badge variant="outline" className="bg-green-100 text-green-800">Confirmed</Badge>;
      case 'completed':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800">Completed</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-red-100 text-red-800">Cancelled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const renderDashboardContent = () => {
    const stats = statsQuery.data as AdminStats;
    
    if (statsQuery.isLoading) {
      return (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }
    
    if (statsQuery.isError) {
      return (
        <div className="py-10 text-center">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-500">Error loading statistics</p>
        </div>
      );
    }
    
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <Users className="h-5 w-5 mr-2 text-primary" />
              Users
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Vendors:</span>
                <span className="font-medium">{stats.totalVendors}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Organizers:</span>
                <span className="font-medium">{stats.totalOrganizers}</span>
              </div>
              <div className="flex justify-between text-orange-500">
                <span>Pending Vendors:</span>
                <span className="font-medium">{stats.pendingVendors}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <Package className="h-5 w-5 mr-2 text-primary" />
              Devices
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Total Devices:</span>
                <span className="font-medium">{stats.totalDevices}</span>
              </div>
              <div className="flex justify-between text-orange-500">
                <span>Pending Approval:</span>
                <span className="font-medium">{stats.pendingDevices}</span>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl flex items-center">
              <Calendar className="h-5 w-5 mr-2 text-primary" />
              Bookings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Active Bookings:</span>
                <span className="font-medium">{stats.activeBookings}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };
  
  const renderPendingVendors = () => {
    if (pendingVendorsQuery.isLoading) {
      return (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }
    
    if (pendingVendorsQuery.isError) {
      return (
        <div className="py-10 text-center">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-500">Error loading pending vendors</p>
        </div>
      );
    }
    
    const pendingVendors = pendingVendorsQuery.data as SafeUser[];
    
    if (!pendingVendors || pendingVendors.length === 0) {
      return (
        <div className="py-10 text-center">
          <p className="text-muted-foreground">No pending vendor applications</p>
        </div>
      );
    }
    
    return (
      <Table>
        <TableCaption>List of vendors awaiting approval</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Username</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Phone</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {pendingVendors.map((vendor) => (
            <TableRow key={vendor.id}>
              <TableCell className="font-medium">{vendor.name}</TableCell>
              <TableCell>{vendor.username}</TableCell>
              <TableCell>{vendor.email}</TableCell>
              <TableCell>{vendor.phone}</TableCell>
              <TableCell className="space-x-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="bg-green-100 hover:bg-green-200 text-green-800"
                  onClick={() => approveVendorMutation.mutate(vendor.id)}
                  disabled={approveVendorMutation.isPending}
                >
                  {approveVendorMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <CheckCircle className="h-4 w-4 mr-1" />}
                  Approve
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="bg-red-100 hover:bg-red-200 text-red-800"
                  onClick={() => rejectVendorMutation.mutate(vendor.id)}
                  disabled={rejectVendorMutation.isPending}
                >
                  {rejectVendorMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <XCircle className="h-4 w-4 mr-1" />}
                  Reject
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };
  
  const renderAllUsers = () => {
    if (usersQuery.isLoading) {
      return (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }
    
    if (usersQuery.isError) {
      return (
        <div className="py-10 text-center">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-500">Error loading users</p>
        </div>
      );
    }
    
    const users = (usersQuery.data as SafeUser[]) || [];
    
    return (
      <Table>
        <TableCaption>All platform users</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Username</TableHead>
            <TableHead>Role</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id}>
              <TableCell className="font-medium">{user.name}</TableCell>
              <TableCell>{user.username}</TableCell>
              <TableCell className="capitalize">{user.role}</TableCell>
              <TableCell>{user.email}</TableCell>
              <TableCell>
                {user.role === "vendor" && (
                  user.isApproved 
                    ? <Badge variant="outline" className="bg-green-100 text-green-800">Approved</Badge>
                    : <Badge variant="outline" className="bg-orange-100 text-orange-800">Pending</Badge>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };
  
  const renderPendingDevices = () => {
    if (pendingDevicesQuery.isLoading) {
      return (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }
    
    if (pendingDevicesQuery.isError) {
      return (
        <div className="py-10 text-center">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-500">Error loading pending devices</p>
        </div>
      );
    }
    
    const pendingDevices = pendingDevicesQuery.data as Device[];
    
    if (!pendingDevices || pendingDevices.length === 0) {
      return (
        <div className="py-10 text-center">
          <p className="text-muted-foreground">No pending devices</p>
        </div>
      );
    }
    
    return (
      <div className="space-y-6">
        {pendingDevices.map((device) => (
          <Card key={device.id}>
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <div className="md:w-1/3">
                  {device.images?.[0] && (
                    <img 
                      src={device.images[0]} 
                      alt={device.name} 
                      className="w-full h-48 object-cover rounded-md"
                    />
                  )}
                </div>
                <div className="md:w-2/3 space-y-4">
                  <div>
                    <h3 className="text-xl font-bold">{device.name}</h3>
                    <p className="text-muted-foreground">
                      {device.brand || ''} {device.model || ''}
                    </p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Category</p>
                      <p>{device.category}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Price per Day</p>
                      <p>₹{device.pricePerDay}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">City</p>
                      <p>{device.city}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Condition</p>
                      <p>{device.condition}</p>
                    </div>
                  </div>
                  
                  <div className="flex space-x-3 mt-4">
                    <Button 
                      variant="outline" 
                      className="bg-green-100 hover:bg-green-200 text-green-800"
                      onClick={() => approveDeviceMutation.mutate(device.id)}
                      disabled={approveDeviceMutation.isPending}
                    >
                      {approveDeviceMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <CheckCircle className="h-4 w-4 mr-1" />}
                      Approve
                    </Button>
                    <Button 
                      variant="outline" 
                      className="bg-red-100 hover:bg-red-200 text-red-800"
                      onClick={() => rejectDeviceMutation.mutate(device.id)}
                      disabled={rejectDeviceMutation.isPending}
                    >
                      {rejectDeviceMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-1" /> : <XCircle className="h-4 w-4 mr-1" />}
                      Reject
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };
  
  const renderBookings = () => {
    if (bookingsQuery.isLoading) {
      return (
        <div className="flex justify-center py-10">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      );
    }
    
    if (bookingsQuery.isError) {
      return (
        <div className="py-10 text-center">
          <AlertTriangle className="h-8 w-8 text-red-500 mx-auto mb-4" />
          <p className="text-red-500">Error loading bookings</p>
        </div>
      );
    }
    
    const bookings = bookingsQuery.data as Booking[];
    
    if (!bookings || bookings.length === 0) {
      return (
        <div className="py-10 text-center">
          <p className="text-muted-foreground">No bookings found</p>
        </div>
      );
    }
    
    return (
      <Table>
        <TableCaption>All bookings</TableCaption>
        <TableHeader>
          <TableRow>
            <TableHead>ID</TableHead>
            <TableHead>Device ID</TableHead>
            <TableHead>Organizer ID</TableHead>
            <TableHead>Dates</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Camp Name</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {bookings.map((booking) => (
            <TableRow key={booking.id}>
              <TableCell className="font-medium">{booking.id}</TableCell>
              <TableCell>{booking.deviceId}</TableCell>
              <TableCell>{booking.organizerId}</TableCell>
              <TableCell>
                {formatDate(booking.startDate)} - {formatDate(booking.endDate)}
              </TableCell>
              <TableCell>{renderStatusBadge(booking.status)}</TableCell>
              <TableCell>{booking.campName || '-'}</TableCell>
              <TableCell>
                {booking.status !== 'cancelled' && booking.status !== 'completed' && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="bg-red-100 hover:bg-red-200 text-red-800"
                    onClick={() => {
                      setSelectedBookingId(booking.id);
                      setDialogOpen(true);
                    }}
                  >
                    <XCircle className="h-4 w-4 mr-1" />
                    Cancel
                  </Button>
                )}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    );
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-5">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="vendors">Vendors</TabsTrigger>
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
        </TabsList>
        
        <div className="mt-6">
          <TabsContent value="dashboard">
            <Card>
              <CardHeader>
                <CardTitle>Platform Overview</CardTitle>
                <CardDescription>Summary of BMD Camp Platform</CardDescription>
              </CardHeader>
              <CardContent>
                {renderDashboardContent()}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="vendors">
            <Card>
              <CardHeader>
                <CardTitle>Pending Vendor Applications</CardTitle>
                <CardDescription>Review and approve vendor registrations</CardDescription>
              </CardHeader>
              <CardContent>
                {renderPendingVendors()}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="devices">
            <Card>
              <CardHeader>
                <CardTitle>Pending Device Listings</CardTitle>
                <CardDescription>Review and approve device listings</CardDescription>
              </CardHeader>
              <CardContent>
                {renderPendingDevices()}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="bookings">
            <Card>
              <CardHeader>
                <CardTitle>All Bookings</CardTitle>
                <CardDescription>Manage and monitor all platform bookings</CardDescription>
              </CardHeader>
              <CardContent>
                {renderBookings()}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="users">
            <Card>
              <CardHeader>
                <CardTitle>User Management</CardTitle>
                <CardDescription>View all platform users</CardDescription>
              </CardHeader>
              <CardContent>
                {renderAllUsers()}
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
      
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Booking</DialogTitle>
            <DialogDescription>
              Please provide a reason for cancelling this booking. This will be shared with both the vendor and the organizer.
            </DialogDescription>
          </DialogHeader>
          
          <div className="py-4">
            <Label htmlFor="reason">Cancellation Reason</Label>
            <Textarea 
              id="reason" 
              value={cancelReason}
              onChange={(e) => setCancelReason(e.target.value)}
              placeholder="Enter reason for cancellation"
              className="mt-2"
            />
          </div>
          
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive"
              onClick={handleCancelBooking}
              disabled={cancelBookingMutation.isPending || !cancelReason.trim()}
            >
              {cancelBookingMutation.isPending && <Loader2 className="h-4 w-4 animate-spin mr-1" />}
              Confirm Cancellation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}