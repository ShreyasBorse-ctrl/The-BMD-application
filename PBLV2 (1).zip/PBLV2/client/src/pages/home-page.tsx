/**
 * Home page component
 * Displays available BMD devices and search functionality
 * Provides device filtering and navigation to dashboard
 */

import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Device } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Loader2,
  LogOut,
  Search,
  Calendar,
  MapPin,
  Filter,
  CheckCircle,
  XCircle,
  RefreshCw,
} from "lucide-react";
import DeviceCard from "@/components/device-card";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Switch } from "@/components/ui/switch";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const [cityFilter, setCityFilter] = useState("");

  // Advanced filters
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 10000]);
  const [categoryFilter, setCategoryFilter] = useState<string>("");
  const [availabilityFilter, setAvailabilityFilter] = useState<boolean>(false);
  const [conditionFilter, setConditionFilter] = useState<string>("");

  const { data: devices, isLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  // Extract unique values for filters
  const uniqueValues = (array: (string | undefined)[]): string[] => {
    const unique: string[] = [];
    array.forEach((item) => {
      if (item && !unique.includes(item)) {
        unique.push(item);
      }
    });
    return unique;
  };

  const categories = uniqueValues(
    devices?.map((device) => device.category) || [],
  );
  const conditions = uniqueValues(
    devices?.map((device) => device.condition) || [],
  );
  const cities = uniqueValues(devices?.map((device) => device.city) || []);
  const maxPrice = Math.max(
    ...(devices?.map((device) => device.pricePerDay) || [0]),
    10000,
  );

  // Reset all filters
  const resetFilters = () => {
    setSearchQuery("");
    setCityFilter("");
    setPriceRange([0, maxPrice]);
    setCategoryFilter("");
    setAvailabilityFilter(false);
    setConditionFilter("");
  };

  const filteredDevices = devices?.filter((device) => {
    // Basic search filters
    const matchesSearch =
      device.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      device.description.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesCity =
      !cityFilter ||
      device.city.toLowerCase().includes(cityFilter.toLowerCase());

    // Advanced filters
    const matchesPrice =
      !showAdvancedFilters ||
      (device.pricePerDay >= priceRange[0] &&
        device.pricePerDay <= priceRange[1]);

    const matchesCategory =
      !showAdvancedFilters ||
      !categoryFilter ||
      device.category === categoryFilter;

    const matchesAvailability =
      !showAdvancedFilters || !availabilityFilter || device.available === true;

    const matchesCondition =
      !showAdvancedFilters ||
      !conditionFilter ||
      device.condition === conditionFilter;

    return (
      matchesSearch &&
      matchesCity &&
      matchesPrice &&
      matchesCategory &&
      matchesAvailability &&
      matchesCondition
    );
  });

  const goToDashboard = () => {
    setLocation(user?.role === "vendor" ? "/vendor" : "/organizer");
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#F5F5F5] to-[#E8F0FE]">
      <section
        style={{
          backgroundImage:
            'url("https://www.makii.com.au/wp-content/uploads/2015/09/Central-Coast-Website-Design-Dark-Grey-BG-1.png")',
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
        className="text-white py-32 relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0zNiAzNGgxMnYxMkgzNnoiLz48cGF0aCBkPSJNMTIgMTJoMTJ2MTJIMTJWMTJNMzYgMTJoMTJ2MTJIMzZWMTJNMTIgMzZoMTJ2MTJIMTJWMzYiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLW9wYWNpdHk9Ii4xIiBzdHJva2Utd2lkdGg9IjIiLz48L2c+PC9zdmc+')] opacity-10 animate-pulse"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
        <div className="container mx-auto px-4 text-center relative">
          <div className="max-w-3xl mx-auto">
            <h1 className="text-6xl font-bold mb-6 animate-fade-in bg-clip-text text-transparent bg-gradient-to-r from-white to-blue-100">
              Organize BMD Camps with Ease
            </h1>
            <p className="text-xl mb-8 opacity-90 animate-slide-up">
              Make your bone health assessments more accessible with our
              reliable services
            </p>
            <div className="flex gap-4 justify-center">
              <Button
                size="lg"
                onClick={goToDashboard}
                className="bg-[#32CD32] hover:bg-[#28a745] text-white shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all"
              >
                Get Started
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-white/10 hover:bg-white/20 text-white border-white/20 shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-7xl mx-auto">
          {/* Search and Filter Section */}
          <div className="bg-white p-6 rounded-xl shadow-lg mb-12 border border-gray-100">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-slate-800">
                Find the Perfect Device
              </h2>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                  className="text-primary flex items-center gap-1.5"
                >
                  <Filter className="h-4 w-4" />
                  {showAdvancedFilters ? "Hide Filters" : "Advanced Filters"}
                </Button>
                {showAdvancedFilters && (
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="outline"
                          size="icon"
                          onClick={resetFilters}
                          className="h-8 w-8 rounded-full"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent>
                        <p>Reset all filters</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                )}
              </div>
            </div>

            <p className="text-slate-600 mb-6">
              Browse our collection of premium bone mineral density machines for
              your camp
            </p>

            {/* Basic Search */}
            <div className="grid gap-4 md:grid-cols-2 mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-5 w-5 text-primary/60" />
                <Input
                  className="pl-10 h-12 border-slate-200 focus:border-primary/40 focus:ring-2 focus:ring-primary/20"
                  placeholder="Search devices by name or description..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-primary/60" />
                <Input
                  className="pl-10 h-12 border-slate-200 focus:border-primary/40 focus:ring-2 focus:ring-primary/20"
                  placeholder="Filter by city location..."
                  value={cityFilter}
                  onChange={(e) => setCityFilter(e.target.value)}
                />
              </div>
            </div>

            {/* Advanced Filters Section */}
            {showAdvancedFilters && (
              <div className="bg-slate-50/50 p-5 rounded-lg border border-slate-100 animate-in fade-in duration-300">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-medium text-slate-800">
                    Advanced Filters
                  </h3>
                  <Badge
                    variant="outline"
                    className="bg-primary/5 text-primary border-primary/10"
                  >
                    {filteredDevices?.length || 0} Matches
                  </Badge>
                </div>

                <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
                  {/* Price Range Filter */}
                  <div className="space-y-3">
                    <Label className="text-slate-700">
                      Price Range (₹/day)
                    </Label>
                    <div className="px-2">
                      <Slider
                        defaultValue={[0, maxPrice]}
                        min={0}
                        max={maxPrice}
                        step={100}
                        value={priceRange}
                        onValueChange={(value) =>
                          setPriceRange(value as [number, number])
                        }
                        className="my-6"
                      />
                      <div className="flex justify-between text-sm text-slate-500">
                        <span>₹{priceRange[0]}</span>
                        <span>₹{priceRange[1]}</span>
                      </div>
                    </div>
                  </div>

                  {/* Category Filter */}
                  <div className="space-y-3">
                    <Label className="text-slate-700">Device Category</Label>
                    <Select
                      value={categoryFilter}
                      onValueChange={setCategoryFilter}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Choose category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Categories</SelectItem>
                        {categories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Condition Filter */}
                  <div className="space-y-3">
                    <Label className="text-slate-700">Device Condition</Label>
                    <Select
                      value={conditionFilter}
                      onValueChange={setConditionFilter}
                    >
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Any condition" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">Any condition</SelectItem>
                        {conditions.map((condition) => (
                          <SelectItem key={condition} value={condition}>
                            {condition}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Availability Toggle */}
                  <div className="space-y-3">
                    <Label className="text-slate-700">Availability</Label>
                    <div className="flex items-center space-x-2 mt-4">
                      <Switch
                        id="available-only"
                        checked={availabilityFilter}
                        onCheckedChange={setAvailabilityFilter}
                      />
                      <Label
                        htmlFor="available-only"
                        className="cursor-pointer"
                      >
                        Show available devices only
                      </Label>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end mt-6">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={resetFilters}
                    className="text-sm"
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Clear All Filters
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Devices Section */}
          <div>
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-slate-800">
                Available Devices
              </h2>
              {filteredDevices && (
                <p className="text-slate-500">
                  Showing {filteredDevices.length}{" "}
                  {filteredDevices.length === 1 ? "device" : "devices"}
                </p>
              )}
            </div>

            {isLoading ? (
              <div className="flex flex-col items-center justify-center py-16 bg-white/50 backdrop-blur-sm rounded-xl">
                <Loader2 className="h-12 w-12 animate-spin text-primary mb-4" />
                <p className="text-slate-500">Loading available devices...</p>
              </div>
            ) : filteredDevices?.length === 0 ? (
              <div className="text-center py-16 bg-white/50 backdrop-blur-sm rounded-xl">
                <div className="mx-auto w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mb-4">
                  <Search className="h-8 w-8 text-slate-400" />
                </div>
                <h3 className="text-xl font-medium text-slate-800 mb-2">
                  No devices found
                </h3>
                <p className="text-slate-500 max-w-md mx-auto">
                  Try adjusting your search or filter criteria to find more
                  devices
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                {filteredDevices?.map((device) => (
                  <DeviceCard
                    key={device.id}
                    device={device}
                    userRole={user?.role || ""}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Call to Action Section */}
          <div className="mt-16 bg-gradient-to-r from-primary/10 to-primary/5 rounded-xl p-8 shadow-inner">
            <div className="flex flex-col md:flex-row md:items-center justify-between">
              <div className="mb-6 md:mb-0 md:mr-8">
                <h3 className="text-xl font-bold text-slate-800 mb-2">
                  Are you a vendor?
                </h3>
                <p className="text-slate-600">
                  List your bone mineral density devices and reach more
                  organizers
                </p>
              </div>
              <Button
                onClick={goToDashboard}
                className="bg-primary hover:bg-primary/90 text-white px-6"
                size="lg"
              >
                Go to Dashboard
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
