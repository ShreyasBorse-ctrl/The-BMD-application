import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Device, Booking } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Loader2 } from "lucide-react";
import DeviceCard from "@/components/device-card";

export default function OrganizerDashboard() {
  const { user } = useAuth();

  const { data: bookings, isLoading: isLoadingBookings } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  const { data: devices, isLoading: isLoadingDevices } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const myBookings = bookings?.filter(
    (booking) => booking.organizerId === user?.id,
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case "confirmed":
        return "bg-green-500";
      case "cancelled":
        return "bg-red-500";
      case "pending":
        return "bg-yellow-500";
      default:
        return "bg-gray-500";
    }
  };

  function calculateTotalCost(booking: Booking, device?: Device): string {
    if (!device) return "₹0";
    const days = getDaysBetween(booking.startDate, booking.endDate);
    return `₹${(device.pricePerDay * days).toLocaleString()}`;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-blue-50 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600 animate-fade-in">
          Organizer Dashboard
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>My Bookings</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingBookings ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : !myBookings?.length ? (
                <p className="text-muted-foreground text-center py-4">
                  No bookings found
                </p>
              ) : (
                <div className="space-y-4">
                  {myBookings.map((booking) => {
                    const device = devices?.find(
                      (d) => d.id === booking.deviceId,
                    );
                    return (
                      <Card key={booking.id}>
                        <CardContent className="pt-6">
                          <div className="flex justify-between items-start">
                            <div>
                              <h3 className="font-medium">
                                {device?.name || "Unknown Device"}
                              </h3>
                              <p className="text-sm text-muted-foreground">
                                {new Date(
                                  booking.startDate,
                                ).toLocaleDateString()}{" "}
                                -{" "}
                                {new Date(booking.endDate).toLocaleDateString()}
                              </p>
                              <div className="mt-2">
                                <Badge
                                  className={getStatusColor(booking.status)}
                                >
                                  {booking.status.charAt(0).toUpperCase() +
                                    booking.status.slice(1)}
                                </Badge>
                              </div>
                            </div>
                            <div>
                              <p className="text-sm font-medium">
                                Total Cost:{" "}
                                {calculateTotalCost(booking, device)}
                              </p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Available Devices</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoadingDevices ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : !devices?.length ? (
                <p className="text-muted-foreground text-center py-4">
                  No devices available
                </p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {devices.map((device) => (
                    <DeviceCard
                      key={device.id}
                      device={device}
                      userRole="organizer"
                    />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function getDaysBetween(start: string | Date, end: string | Date): number {
  const startDate = new Date(start);
  const endDate = new Date(end);
  const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}
