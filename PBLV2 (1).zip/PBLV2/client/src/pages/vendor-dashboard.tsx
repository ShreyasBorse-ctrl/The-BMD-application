import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Device, Booking } from "@shared/schema";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCircle, XCircle, Calendar, MapPin, Eye, Info } from "lucide-react";
import { DeviceForm } from "@/components/device-form";
import DeviceCard from "@/components/device-card";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format } from "date-fns";
import { BookingDetailsDialog } from "@/components/BookingDetailsDialog";

export default function VendorDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: devices, isLoading: isLoadingDevices } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const { data: bookings, isLoading: isLoadingBookings } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  const updateBookingMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number; status: "confirmed" | "cancelled" }) => {
      const response = await apiRequest("PATCH", `/api/bookings/${id}/status`, { status });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update booking');
      }
      return response.json();
    },
    onSuccess: (updatedBooking) => {
      // Update the cache directly with the updated booking
      queryClient.setQueryData<Booking[]>(["/api/bookings"], (oldBookings) => {
        if (!oldBookings) return oldBookings;
        
        // Replace the updated booking in the cache
        return oldBookings.map(booking => 
          booking.id === updatedBooking.id ? updatedBooking : booking
        );
      });
      
      // Also invalidate the query to ensure fresh data on next request
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      
      toast({
        title: "Booking updated",
        description: "The booking status has been updated successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating booking",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const myDevices = devices?.filter(device => device.vendorId === user?.id);

  const pendingBookings = bookings?.filter(booking => 
    devices?.find(d => d.vendorId === user?.id && d.id === booking.deviceId) &&
    booking.status === "pending"
  );

  const confirmedBookings = bookings?.filter(booking => 
    devices?.find(d => d.vendorId === user?.id && d.id === booking.deviceId) &&
    booking.status === "confirmed"
  );

  function handleBookingAction(id: number, status: "confirmed" | "cancelled") {
    updateBookingMutation.mutate({ id, status });
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-blue-50 p-8">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-600">
          Vendor Dashboard
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Add New Device</CardTitle>
            </CardHeader>
            <CardContent>
              <DeviceForm />
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Pending Bookings</span>
                  {pendingBookings && (
                    <Badge variant="secondary">{pendingBookings.length}</Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingBookings ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : !pendingBookings?.length ? (
                  <p className="text-muted-foreground text-center py-4">No pending bookings</p>
                ) : (
                  <div className="space-y-4">
                    {pendingBookings?.map((booking) => {
                      const device = devices?.find(d => d.id === booking.deviceId);
                      return (
                        <Card key={booking.id}>
                          <CardContent className="pt-6">
                            <div className="flex flex-col space-y-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-medium text-lg">{device?.name}</h3>
                                  <div className="flex items-center text-sm text-muted-foreground mt-1">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    {format(new Date(booking.startDate), "PPP")} - {format(new Date(booking.endDate), "PPP")}
                                  </div>
                                  <div className="flex items-center text-sm text-muted-foreground mt-1">
                                    <MapPin className="h-4 w-4 mr-1" />
                                    {booking.city}
                                  </div>
                                </div>
                                <Badge>{booking.status}</Badge>
                              </div>
                              <div className="flex flex-col space-y-2">
                                <div className="flex space-x-2">
                                  <Button
                                    variant="default"
                                    size="sm"
                                    className="w-full"
                                    onClick={() => handleBookingAction(booking.id, "confirmed")}
                                    disabled={updateBookingMutation.isPending}
                                  >
                                    <CheckCircle className="h-4 w-4 mr-2" />
                                    Accept
                                  </Button>
                                  <Button
                                    variant="destructive"
                                    size="sm"
                                    className="w-full"
                                    onClick={() => handleBookingAction(booking.id, "cancelled")}
                                    disabled={updateBookingMutation.isPending}
                                  >
                                    <XCircle className="h-4 w-4 mr-2" />
                                    Reject
                                  </Button>
                                </div>
                                <BookingDetailsDialog
                                  booking={booking}
                                  device={device}
                                  trigger={
                                    <Button variant="outline" size="sm" className="w-full">
                                      <Eye className="h-4 w-4 mr-2" />
                                      View Camp Details
                                    </Button>
                                  }
                                />
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Confirmed Bookings</span>
                  {confirmedBookings && (
                    <Badge variant="secondary">{confirmedBookings.length}</Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingBookings ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : !confirmedBookings?.length ? (
                  <p className="text-muted-foreground text-center py-4">No confirmed bookings</p>
                ) : (
                  <div className="space-y-4">
                    {confirmedBookings?.map((booking) => {
                      const device = devices?.find(d => d.id === booking.deviceId);
                      return (
                        <Card key={booking.id}>
                          <CardContent className="pt-6">
                            <div className="flex flex-col space-y-4">
                              <div className="flex justify-between items-start">
                                <div>
                                  <h3 className="font-medium text-lg">{device?.name}</h3>
                                  <div className="flex items-center text-sm text-muted-foreground mt-1">
                                    <Calendar className="h-4 w-4 mr-1" />
                                    {format(new Date(booking.startDate), "PPP")} - {format(new Date(booking.endDate), "PPP")}
                                  </div>
                                  <div className="flex items-center text-sm text-muted-foreground mt-1">
                                    <MapPin className="h-4 w-4 mr-1" />
                                    {booking.city}
                                  </div>
                                </div>
                                <Badge variant="secondary" className="bg-green-500 hover:bg-green-600">{booking.status}</Badge>
                              </div>
                              <BookingDetailsDialog
                                booking={booking}
                                device={device}
                                trigger={
                                  <Button variant="outline" size="sm" className="w-full">
                                    <Info className="h-4 w-4 mr-2" />
                                    Camp Details
                                  </Button>
                                }
                              />
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>My Devices</CardTitle>
              </CardHeader>
              <CardContent>
                {isLoadingDevices ? (
                  <div className="flex justify-center py-4">
                    <Loader2 className="h-6 w-6 animate-spin" />
                  </div>
                ) : myDevices?.length === 0 ? (
                  <p className="text-muted-foreground text-center py-4">No devices listed</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {myDevices?.map((device) => (
                      <DeviceCard key={device.id} device={device} userRole="vendor" />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}