import React, { useEffect, useState } from 'react';
import { Calendar } from '@/components/ui/calendar';
import { Device } from '@shared/schema';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent } from '@/components/ui/card';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { DateRange } from 'react-day-picker';

interface ColorCodedCalendarProps {
  device: Device;
  onStartDateSelect?: (date: Date | undefined) => void;
  onEndDateSelect?: (date: Date | undefined) => void;
  selectedStartDate?: Date;
  selectedEndDate?: Date;
  mode?: 'single' | 'range' | 'view';
  isViewOnly?: boolean;
  setHasConflict?: (hasConflict: boolean) => void;
  requestedQuantity?: number;
}

export function ColorCodedCalendar({
  device,
  onStartDateSelect,
  onEndDateSelect,
  selectedStartDate,
  selectedEndDate,
  mode = 'view',
  isViewOnly = false,
  setHasConflict,
  requestedQuantity = 1
}: ColorCodedCalendarProps) {
  const [dateOccupancy, setDateOccupancy] = useState<{[date: string]: number}>({});
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(selectedStartDate);
  const [rangeDate, setRangeDate] = useState<DateRange | undefined>(
    selectedStartDate && selectedEndDate 
      ? { from: selectedStartDate, to: selectedEndDate } 
      : undefined
  );

  useEffect(() => {
    async function fetchAvailability() {
      setLoading(true);
      try {
        // Calculate dates for next 60 days
        const startDate = new Date();
        const endDate = new Date();
        endDate.setDate(endDate.getDate() + 60);
        
        // Fetch all bookings for the device
        const res = await apiRequest('GET', `/api/devices/${device.id}/bookings`);
        if (!res.ok) {
          throw new Error('Failed to load device bookings');
        }
        
        const bookings = await res.json();
        
        // Calculate occupancy for each day
        const occupancy: {[date: string]: number} = {};
        
        // Initialize all dates with 0 bookings
        for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
          const dateStr = format(d, 'yyyy-MM-dd');
          occupancy[dateStr] = 0;
        }
        
        // Count bookings for each day
        // End date is exclusive - a booking from Mar 1 to Mar 2 only occupies Mar 1
        for (const booking of bookings) {
          const bookingStart = new Date(booking.startDate);
          const bookingEnd = new Date(booking.endDate);
          
          for (let d = new Date(bookingStart); d < bookingEnd; d.setDate(d.getDate() + 1)) {
            const dateStr = format(d, 'yyyy-MM-dd');
            occupancy[dateStr] = (occupancy[dateStr] || 0) + booking.quantity;
          }
        }
        
        setDateOccupancy(occupancy);
      } catch (error) {
        console.error('Error fetching availability:', error);
      } finally {
        setLoading(false);
      }
    }
    
    if (device?.id) {
      fetchAvailability();
    }
  }, [device.id]);

  // Determine if a date is fully booked
  const isDateFullyBooked = (date: Date): boolean => {
    const dateString = format(date, 'yyyy-MM-dd');
    const booked = dateOccupancy[dateString] || 0;
    return booked >= device.quantity;
  };
  
  // Determine if a date is partially booked
  const isDatePartiallyBooked = (date: Date): boolean => {
    const dateString = format(date, 'yyyy-MM-dd');
    const booked = dateOccupancy[dateString] || 0;
    return booked > 0 && booked < device.quantity;
  };
  
  // Get remaining quantity for a date
  const getRemainingQuantity = (date: Date): number => {
    const dateString = format(date, 'yyyy-MM-dd');
    const booked = dateOccupancy[dateString] || 0;
    return Math.max(0, device.quantity - booked);
  };

  // Today's date for disabling past dates
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  // Check for conflicts in selected date range and update the parent component
  useEffect(() => {
    if (setHasConflict && selectedStartDate && selectedEndDate) {
      // Check if any dates in the range have conflicts
      let hasConflict = false;
      
      for (let d = new Date(selectedStartDate); d < selectedEndDate; d.setDate(d.getDate() + 1)) {
        const dateStr = format(d, 'yyyy-MM-dd');
        const booked = dateOccupancy[dateStr] || 0;
        const available = device.quantity - booked;
        
        // If requested quantity exceeds available, we have a conflict
        if (available < requestedQuantity) {
          hasConflict = true;
          break;
        }
      }
      
      setHasConflict(hasConflict);
    }
  }, [selectedStartDate, selectedEndDate, dateOccupancy, device.quantity, requestedQuantity, setHasConflict]);

  if (mode === 'single') {
    return (
      <Card>
        <CardContent className="p-4">
          <h3 className="text-lg font-medium mb-3">Availability Calendar</h3>
          
          {loading ? (
            <div className="flex justify-center py-4">Loading availability...</div>
          ) : (
            <>
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={(date) => {
                  if (isViewOnly) return;
                  setSelectedDate(date);
                  if (onStartDateSelect) onStartDateSelect(date);
                }}
                disabled={(date) => {
                  // For view only mode or past dates
                  if (date < today) return true;
                  
                  // Disable fully booked dates
                  if (!isViewOnly) {
                    const dateString = format(date, 'yyyy-MM-dd');
                    const booked = dateOccupancy[dateString] || 0;
                    return booked >= device.quantity;
                  }
                  
                  return false;
                }}
                className="rounded-md border"
                modifiers={{
                  booked: Object.entries(dateOccupancy)
                    .filter(([_, count]) => Number(count) >= device.quantity)
                    .map(([date]) => new Date(date)),
                  partiallyBooked: Object.entries(dateOccupancy)
                    .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                    .map(([date]) => new Date(date))
                }}
                modifiersClassNames={{
                  booked: "bg-red-100 text-red-900",
                  partiallyBooked: "bg-orange-100 text-orange-900"
                }}
              />
              
              <div className="flex flex-wrap mt-3 gap-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-100 border border-green-300 rounded-sm" />
                  <span className="text-sm">Available ({device.quantity} units)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-orange-100 border border-orange-300 rounded-sm" />
                  <span className="text-sm">Partially Booked</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-100 border border-red-300 rounded-sm" />
                  <span className="text-sm">Fully Booked</span>
                </div>
              </div>
              
              {Object.entries(dateOccupancy)
                .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                .length > 0 && (
                <div className="mt-3 text-sm text-muted-foreground">
                  <p className="font-semibold">Partially booked dates availability:</p>
                  <ul className="mt-1 space-y-1">
                    {Object.entries(dateOccupancy)
                      .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                      .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
                      .slice(0, 3)
                      .map(([date, count]) => (
                        <li key={date} className="flex justify-between">
                          <span>{format(new Date(date), 'MMM d, yyyy')}</span>
                          <span className="font-medium">{device.quantity - Number(count)}/{device.quantity} units available</span>
                        </li>
                      ))}
                    {Object.entries(dateOccupancy)
                      .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                      .length > 3 && <li className="text-center italic">+ more dates...</li>}
                  </ul>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    );
  }
  
  if (mode === 'range') {
    return (
      <Card>
        <CardContent className="p-4">
          <h3 className="text-lg font-medium mb-3">Availability Calendar</h3>
          
          {loading ? (
            <div className="flex justify-center py-4">Loading availability...</div>
          ) : (
            <>
              <Calendar
                mode="range"
                selected={rangeDate}
                onSelect={(range) => {
                  if (isViewOnly) return;
                  
                  setRangeDate(range);
                  
                  if (range?.from) {
                    if (onStartDateSelect) onStartDateSelect(range.from);
                  } else {
                    if (onStartDateSelect) onStartDateSelect(undefined);
                  }
                  
                  if (range?.to) {
                    if (onEndDateSelect) onEndDateSelect(range.to);
                  } else {
                    if (onEndDateSelect) onEndDateSelect(undefined);
                  }
                }}
                disabled={(date) => {
                  // No booking in past
                  if (date < today) return true;
                  
                  // For end date selection, only make sure it's after start
                  if (rangeDate?.from && !rangeDate.to) {
                    return date < rangeDate.from;
                  }
                  
                  // For start date selection, disable fully booked dates
                  if (!isViewOnly && !rangeDate?.from) {
                    const dateString = format(date, 'yyyy-MM-dd');
                    const booked = dateOccupancy[dateString] || 0;
                    return booked >= device.quantity;
                  }
                  
                  return false;
                }}
                className="rounded-md border"
                modifiers={{
                  booked: Object.entries(dateOccupancy)
                    .filter(([_, count]) => Number(count) >= device.quantity)
                    .map(([date]) => new Date(date)),
                  partiallyBooked: Object.entries(dateOccupancy)
                    .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                    .map(([date]) => new Date(date))
                }}
                modifiersClassNames={{
                  booked: "bg-red-100 text-red-900",
                  partiallyBooked: "bg-orange-100 text-orange-900"
                }}
              />
              
              <div className="flex flex-wrap mt-3 gap-3">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-100 border border-green-300 rounded-sm" />
                  <span className="text-sm">Available ({device.quantity} units)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-orange-100 border border-orange-300 rounded-sm" />
                  <span className="text-sm">Partially Booked</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-100 border border-red-300 rounded-sm" />
                  <span className="text-sm">Fully Booked</span>
                </div>
              </div>
              
              {Object.entries(dateOccupancy)
                .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                .length > 0 && (
                <div className="mt-3 text-sm text-muted-foreground">
                  <p className="font-semibold">Partially booked dates availability:</p>
                  <ul className="mt-1 space-y-1">
                    {Object.entries(dateOccupancy)
                      .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                      .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
                      .slice(0, 3)
                      .map(([date, count]) => (
                        <li key={date} className="flex justify-between">
                          <span>{format(new Date(date), 'MMM d, yyyy')}</span>
                          <span className="font-medium">{device.quantity - Number(count)}/{device.quantity} units available</span>
                        </li>
                      ))}
                    {Object.entries(dateOccupancy)
                      .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                      .length > 3 && <li className="text-center italic">+ more dates...</li>}
                  </ul>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    );
  }
  
  // View mode (default)
  return (
    <Card>
      <CardContent className="p-4">
        <h3 className="text-lg font-medium mb-3">Availability Calendar</h3>
        
        {loading ? (
          <div className="flex justify-center py-4">Loading availability...</div>
        ) : (
          <>
            <Calendar
              mode="single"
              disabled={(date) => date < today}
              modifiers={{
                fullyBooked: Object.entries(dateOccupancy)
                  .filter(([_, count]) => Number(count) >= device.quantity)
                  .map(([date]) => new Date(date)),
                partiallyBooked: Object.entries(dateOccupancy)
                  .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                  .map(([date]) => new Date(date))
              }}
              modifiersClassNames={{
                fullyBooked: "bg-red-100 text-red-900",
                partiallyBooked: "bg-orange-100 text-orange-900"
              }}
              className="rounded-md border"
            />
            
            <div className="flex flex-wrap mt-3 gap-3">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-100 border border-green-300 rounded-sm" />
                <span className="text-sm">Available ({device.quantity} units)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-orange-100 border border-orange-300 rounded-sm" />
                <span className="text-sm">Partially Booked</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-red-100 border border-red-300 rounded-sm" />
                <span className="text-sm">Fully Booked</span>
              </div>
            </div>
            
            {Object.entries(dateOccupancy)
              .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
              .length > 0 && (
              <div className="mt-3 text-sm text-muted-foreground">
                <p className="font-semibold">Partially booked dates availability:</p>
                <ul className="mt-1 space-y-1">
                  {Object.entries(dateOccupancy)
                    .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                    .sort((a, b) => new Date(a[0]).getTime() - new Date(b[0]).getTime())
                    .slice(0, 5)
                    .map(([date, count]) => (
                      <li key={date} className="flex justify-between">
                        <span>{format(new Date(date), 'MMM d, yyyy')}</span>
                        <span className="font-medium">{device.quantity - Number(count)}/{device.quantity} units available</span>
                      </li>
                    ))}
                  {Object.entries(dateOccupancy)
                    .filter(([_, count]) => Number(count) > 0 && Number(count) < device.quantity)
                    .length > 5 && <li className="text-center italic">+ more dates...</li>}
                </ul>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}