import React from "react";

const AboutUs: React.FC = () => {
  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-4xl font-bold mb-6">About Us</h1>
      <p className="mb-6">
        Welcome to BMD Camp! Our mission is to provide accessible and reliable
        bone mineral density assessment services. We partner with vendors to
        connect them with camp organizers, making it easier for everyone to
        access essential healthcare resources.
      </p>
      <h2 className="text-2xl font-semibold mt-6">Our Vision</h2>
      <p className="mb-4">
        We strive to create a seamless experience for both vendors and
        organizers, ensuring that bone health assessments can be conducted
        efficiently and effectively across various locations.
      </p>
      <h2 className="text-2xl font-semibold mt-6">Our Team</h2>
      <p className="mb-4">
        Our dedicated team is committed to improving the quality of healthcare
        services by making technology and resources more accessible. We value
        collaboration, innovation, and transparency in all our operations.
      </p>
      <h2 className="text-2xl font-semibold mt-6">Contact Us</h2>
      <p>
        If you have any questions or would like more information, please reach
        out to us at{" "}
        <a href="mailto:support@bmdcamp.in" className="text-blue-500">
          support@bmdcamp.in
        </a>
        .
      </p>
    </div>
  );
};

export default AboutUs;
