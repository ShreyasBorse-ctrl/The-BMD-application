// File deleted as we're no longer using Google Maps integration
