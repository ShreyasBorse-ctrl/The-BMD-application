import { useQuery } from "@tanstack/react-query";
import { Calendar } from "@/components/ui/calendar";
import { Booking, Device } from "@shared/schema";
import { addDays, isWithinInterval, isSameDay, format } from "date-fns";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface AvailabilityCalendarProps {
  device: Device;
  selectedStartDate?: Date;
  selectedEndDate?: Date;
  onStartDateSelect?: (date: Date | undefined) => void;
  onEndDateSelect?: (date: Date | undefined) => void;
  setHasConflict: (hasConflict: boolean) => void;
  requestedQuantity?: number;
}

export function AvailabilityCalendar({
  device,
  selectedStartDate,
  selectedEndDate,
  onStartDateSelect,
  onEndDateSelect,
  setHasConflict,
  requestedQuantity = 1,
}: AvailabilityCalendarProps) {
  const { data: bookings = [] } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
  });

  // Get all confirmed bookings for this device
  const deviceBookings = bookings.filter(
    (booking) => booking.deviceId === device.id && booking.status === "confirmed"
  );

  // Calculate total devices booked for each date
  // End date is exclusive - a booking from Mar 1 to Mar 2 only occupies Mar 1
  const getDevicesBookedOnDate = (date: Date): number => {
    return deviceBookings.reduce((total, booking) => {
      const start = new Date(booking.startDate);
      const end = new Date(booking.endDate);
      
      // Check if date is within range: [start, end) - inclusive start, exclusive end
      if (date >= start && date < end) {
        return total + (booking.quantity || 1); // Add the quantity from each booking
      }
      return total;
    }, 0);
  };

  // Check if a date has all available units booked
  const isDateFullyBooked = (date: Date) => {
    const bookedUnits = getDevicesBookedOnDate(date);
    return bookedUnits >= device.quantity;
  };

  // Check if a date has any bookings (for display purposes)
  const isDatePartiallyBooked = (date: Date) => {
    const bookedUnits = getDevicesBookedOnDate(date);
    return bookedUnits > 0 && bookedUnits < device.quantity;
  };

  // Check if selected date range conflicts with any booking based on quantity
  // Using exclusive end date (end date not included in the booking)
  const hasConflict = (start: Date, end: Date) => {
    // Check each day in the range [start, end)
    let current = new Date(start);
    while (current < end) { // < instead of <= because end date is exclusive
      const bookedUnits = getDevicesBookedOnDate(current);
      
      // If not enough units available for any day in the range, there's a conflict
      if (bookedUnits + requestedQuantity > device.quantity) {
        return true;
      }
      
      current = addDays(current, 1);
    }
    return false;
  };

  // Generate the booked dates to highlight in the calendar - accounting for exclusive end date
  const bookedDates = deviceBookings.flatMap((booking) => {
    const dates = [];
    let currentDate = new Date(booking.startDate);
    const endDate = new Date(booking.endDate);

    while (currentDate < endDate) { // < instead of <= because end date is exclusive
      dates.push(new Date(currentDate));
      currentDate = addDays(currentDate, 1);
    }
    return dates;
  });

  // Custom day render to show booking status with quantity information
  const renderDay = (day: Date) => {
    const isFullyBooked = isDateFullyBooked(day);
    const isPartiallyBooked = isDatePartiallyBooked(day);
    const bookedUnits = getDevicesBookedOnDate(day);
    
    // Check for conflicts in the selected range, respecting exclusive end date
    const hasSelectedConflict = selectedStartDate && selectedEndDate && 
      day >= selectedStartDate && day < selectedEndDate && // End date is exclusive
      bookedUnits + requestedQuantity > device.quantity;

    return (
      <div
        className={cn(
          "w-full h-full p-2 flex flex-col items-center justify-center rounded-md relative",
          isFullyBooked && "bg-red-100",
          isPartiallyBooked && "bg-orange-100",
          hasSelectedConflict && "bg-yellow-100 border border-yellow-500"
        )}
      >
        <span>{format(day, "d")}</span>
        {(isPartiallyBooked || isFullyBooked) && (
          <span className="text-xs font-medium">
            {bookedUnits}/{device.quantity}
          </span>
        )}
      </div>
    );
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-2 text-sm">
            <Badge variant="outline" className="bg-red-100">Fully Booked</Badge>
            <Badge variant="outline" className="bg-orange-100">Partially Booked</Badge>
            <Badge variant="outline" className="bg-yellow-100 border border-yellow-500">Unavailable</Badge>
            <Badge variant="outline" className="bg-primary text-primary-foreground">Selected</Badge>
          </div>
          <Calendar
            mode="range"
            selected={{
              from: selectedStartDate,
              to: selectedEndDate,
            }}
            onSelect={(range) => {
              if (!range?.from || !range?.to) {
                onStartDateSelect?.(undefined);
                onEndDateSelect?.(undefined);
                setHasConflict(false);
                return;
              }

              const conflict = hasConflict(range.from, range.to);
              setHasConflict(conflict);
              onStartDateSelect?.(range.from);
              onEndDateSelect?.(range.to);
            }}
            disabled={(date) => date < new Date()}
            components={{
              Day: ({ date }) => renderDay(date),
            }}
          />
        </div>
      </CardContent>
    </Card>
  );
}