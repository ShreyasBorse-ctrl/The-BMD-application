import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { Device, insertDeviceSchema } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { Trash2, Plus, X } from "lucide-react";
import ReactQuill from "react-quill";
import 'react-quill/dist/quill.snow.css';

interface Specification {
  name: string;
  value: string;
}

interface DeviceEditFormProps {
  device: Device;
  onSuccess?: () => void;
}

export function DeviceEditForm({ device, onSuccess }: DeviceEditFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [specs, setSpecs] = useState<Specification[]>([]);
  const [richDescription, setRichDescription] = useState(device.description);
  const [activeTab, setActiveTab] = useState('basic');
  const [existingImages, setExistingImages] = useState<string[]>(device.images || []);
  const [imageInputKey, setImageInputKey] = useState(Date.now()); // For resetting file input

  // Parse specifications from device
  useEffect(() => {
    if (device.specifications && device.specifications.length > 0) {
      const parsedSpecs: Specification[] = [];
      for (const spec of device.specifications) {
        try {
          // Try to parse JSON objects
          const parsedSpec = JSON.parse(spec);
          if (parsedSpec && typeof parsedSpec === 'object' && 'name' in parsedSpec && 'value' in parsedSpec) {
            parsedSpecs.push(parsedSpec);
          }
        } catch (error) {
          // If parsing fails, try splitting by colon
          const parts = spec.split(':');
          if (parts.length === 2) {
            parsedSpecs.push({ name: parts[0].trim(), value: parts[1].trim() });
          }
        }
      }
      setSpecs(parsedSpecs);
    }
  }, [device.specifications]);

  const form = useForm({
    resolver: zodResolver(insertDeviceSchema),
    defaultValues: {
      name: device.name,
      description: device.description,
      category: device.category,
      pricePerDay: device.pricePerDay,
      quantity: device.quantity,
      city: device.city,
      condition: device.condition,
      images: device.images || [],
      brand: device.brand || "",
      model: device.model || "",
    },
  });

  // Add a specification field
  const addSpec = () => {
    setSpecs([...specs, { name: "", value: "" }]);
  };

  // Update a specification
  const updateSpec = (index: number, field: 'name' | 'value', value: string) => {
    const newSpecs = [...specs];
    newSpecs[index][field] = value;
    setSpecs(newSpecs);
  };

  // Remove a specification
  const removeSpec = (index: number) => {
    const newSpecs = [...specs];
    newSpecs.splice(index, 1);
    setSpecs(newSpecs);
  };

  // Handle removing an existing image
  const removeImage = (index: number) => {
    const newImages = [...existingImages];
    newImages.splice(index, 1);
    setExistingImages(newImages);
    form.setValue('images', newImages);
  };

  // Handle file upload
  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const maxImages = 5;
    const remainingSlots = maxImages - existingImages.length;
    
    if (files.length > remainingSlots) {
      toast({
        title: "Too many images",
        description: `You can only upload ${remainingSlots} more image${remainingSlots !== 1 ? 's' : ''}. Maximum total is 5.`,
        variant: "destructive",
      });
      // Reset the file input
      setImageInputKey(Date.now());
      return;
    }

    const newImages: string[] = [...existingImages];
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      
      // Check if file is an image
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid file type",
          description: `${file.name} is not an image.`,
          variant: "destructive",
        });
        continue;
      }
      
      // Check file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: `${file.name} is larger than 5MB.`,
          variant: "destructive",
        });
        continue;
      }
      
      // Convert to base64
      const reader = new FileReader();
      reader.onload = (e) => {
        if (e.target?.result) {
          newImages.push(e.target.result.toString());
          // Update form value when all files are processed
          if (newImages.length === existingImages.length + i + 1) {
            setExistingImages(newImages);
            form.setValue('images', newImages);
          }
        }
      };
      reader.readAsDataURL(file);
    }
    
    // Reset the file input
    setImageInputKey(Date.now());
  };

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", `/api/devices/${device.id}`, data);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update device');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Device updated",
        description: "Your device has been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/devices/${device.id}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      if (onSuccess) onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: "Error updating device",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(values: any) {
    // Convert specifications to the format expected by the API
    const formattedSpecs = specs.map(spec => JSON.stringify(spec));
    
    // Create the submission data
    const submissionData = {
      ...values,
      description: richDescription,
      specifications: formattedSpecs
    };
    
    updateMutation.mutate(submissionData);
  }

  return (
    <div className="container max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Edit Device Details</h2>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="basic">Basic Info</TabsTrigger>
          <TabsTrigger value="specs">Specifications</TabsTrigger>
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="images">Images</TabsTrigger>
        </TabsList>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Info Tab */}
            <TabsContent value="basic" className="space-y-6 pt-4">
              <div className="grid grid-cols-1 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Device Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter device name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="brand"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Brand (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. GE Healthcare" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="model"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model (Optional)</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g. Achilles II+" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Device Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Portable Ultrasound (QUS) – Heel/Wrist Scanner">Portable Ultrasound (QUS) – Heel/Wrist Scanner</SelectItem>
                          <SelectItem value="Peripheral DEXA (pDEXA) – Wrist/Forearm Scanner">Peripheral DEXA (pDEXA) – Wrist/Forearm Scanner</SelectItem>
                          <SelectItem value="Handheld BMD Device">Handheld BMD Device</SelectItem>
                          <SelectItem value="Semi-Portable DEXA – Tabletop Scanner">Semi-Portable DEXA – Tabletop Scanner</SelectItem>
                          <SelectItem value="Peripheral QCT (pQCT) – Forearm/Tibia Scanner">Peripheral QCT (pQCT) – Forearm/Tibia Scanner</SelectItem>
                          <SelectItem value="Full-Body DEXA (DXA) – Clinical Use">Full-Body DEXA (DXA) – Clinical Use</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="pricePerDay"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Price per Day (₹)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0"
                            step="1"
                            placeholder="1000" 
                            {...field} 
                            onChange={e => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="quantity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Available Quantity</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="1"
                            step="1"
                            placeholder="1" 
                            {...field} 
                            onChange={e => field.onChange(parseInt(e.target.value) || 1)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <FormControl>
                          <Input placeholder="Mumbai" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="condition"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Device Condition</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select condition" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="New">New</SelectItem>
                            <SelectItem value="Refurbished">Refurbished</SelectItem>
                            <SelectItem value="Used - Good">Used - Good</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </TabsContent>
            
            {/* Specifications Tab */}
            <TabsContent value="specs" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Specifications</h3>
                  <div className="space-y-4">
                    {specs.map((spec, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <div className="flex-1">
                          <Input
                            placeholder="Specification name"
                            value={spec.name}
                            onChange={(e) => updateSpec(index, 'name', e.target.value)}
                          />
                        </div>
                        <div className="flex-1">
                          <Input
                            placeholder="Specification value"
                            value={spec.value}
                            onChange={(e) => updateSpec(index, 'value', e.target.value)}
                          />
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => removeSpec(index)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    
                    <Button
                      type="button"
                      variant="outline"
                      onClick={addSpec}
                      className="mt-2"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add Specification
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Description Tab */}
            <TabsContent value="description" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Description</h3>
                  <div className="min-h-[250px]">
                    <ReactQuill 
                      theme="snow" 
                      value={richDescription} 
                      onChange={setRichDescription}
                      placeholder="Describe your device in detail..."
                      modules={{
                        toolbar: [
                          [{ 'header': [1, 2, 3, false] }],
                          ['bold', 'italic', 'underline', 'strike'],
                          [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                          ['link'],
                          ['clean']
                        ],
                      }}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Images Tab */}
            <TabsContent value="images" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Images</h3>
                  
                  {/* Display existing images with remove buttons */}
                  {existingImages.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
                      {existingImages.map((image, index) => (
                        <div key={index} className="relative group">
                          <img 
                            src={image} 
                            alt={`Device Image ${index + 1}`} 
                            className="w-full h-32 object-cover rounded-md"
                          />
                          <button
                            type="button"
                            onClick={() => removeImage(index)}
                            className="absolute top-2 right-2 bg-white/80 hover:bg-white rounded-full p-1 shadow-sm opacity-80 group-hover:opacity-100 transition"
                          >
                            <X className="h-4 w-4 text-red-600" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {/* Image upload */}
                  {existingImages.length < 5 && (
                    <div className="mt-4">
                      <FormField
                        control={form.control}
                        name="images"
                        render={() => (
                          <FormItem>
                            <FormLabel>Add Images (Maximum 5)</FormLabel>
                            <FormControl>
                              <div className="flex items-center space-x-2">
                                <Input 
                                  key={imageInputKey}
                                  type="file" 
                                  accept="image/*" 
                                  multiple
                                  onChange={handleImageUpload}
                                  className="flex-1"
                                />
                              </div>
                            </FormControl>
                            <FormDescription>
                              Upload images of your device from different angles. 
                              {existingImages.length > 0 && ` You can add ${5 - existingImages.length} more image(s).`}
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <div className="flex justify-end pt-4">
              <Button type="submit" disabled={updateMutation.isPending}>
                {updateMutation.isPending ? "Updating..." : "Update Device"}
              </Button>
            </div>
          </form>
        </Form>
      </Tabs>
    </div>
  );
}