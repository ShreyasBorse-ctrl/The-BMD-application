import { Device } from "@shared/schema";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useState } from "react";
import { MapPin, ExternalLink, Calendar, Tag, Star, Activity, Package2, Edit } from "lucide-react";
import { Link } from "wouter";
import { BookingRequestForm } from "@/components/BookingRequestForm";
import { Badge } from "@/components/ui/badge";
import { AspectRatio } from "@/components/ui/aspect-ratio";

interface DeviceCardProps {
  device: Device;
  userRole: string;
}

export default function DeviceCard({ device, userRole }: DeviceCardProps) {
  const [bookingDialogOpen, setBookingDialogOpen] = useState(false);
  
  // Get the main specifications to display (limited to 2)
  const getMainSpecs = () => {
    if (!device.specifications || device.specifications.length === 0) return [];
    
    const parsedSpecs: { name: string; value: string }[] = [];
    
    for (const spec of device.specifications) {
      try {
        const parsedSpec = JSON.parse(spec);
        if (parsedSpec && typeof parsedSpec === 'object' && 'name' in parsedSpec && 'value' in parsedSpec) {
          parsedSpecs.push(parsedSpec);
        }
      } catch (error) {
        const parts = spec.split(':');
        if (parts.length === 2) {
          parsedSpecs.push({ name: parts[0].trim(), value: parts[1].trim() });
        }
      }
      
      if (parsedSpecs.length >= 2) break;
    }
    
    return parsedSpecs;
  };

  // Get first image from device images array or use a placeholder
  const deviceImage = device.images && device.images.length > 0 
    ? device.images[0] 
    : null;

  return (
    <Card className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/95 backdrop-blur-sm flex flex-col overflow-hidden">
      {/* Image Section */}
      <div className="relative">
        <AspectRatio ratio={16/9} className="bg-muted overflow-hidden">
          {deviceImage ? (
            <img 
              src={deviceImage} 
              alt={device.name}
              className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-105"
            />
          ) : (
            <div className="flex items-center justify-center h-full bg-gradient-to-br from-primary/5 to-primary/10">
              <Package2 className="h-16 w-16 text-primary/40" />
            </div>
          )}
        </AspectRatio>
        
        {/* Price Badge */}
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="font-semibold shadow-md text-md px-2.5 py-1">
            ₹{device.pricePerDay.toLocaleString()}/day
          </Badge>
        </div>
        
        {/* Category Badge */}
        <div className="absolute bottom-2 left-2">
          <Badge variant="outline" className="bg-white/80 shadow backdrop-blur-sm text-xs">
            {device.category}
          </Badge>
        </div>
      </div>
      
      <CardHeader className="pt-3 pb-1 px-4">
        <CardTitle className="text-lg font-semibold tracking-tight line-clamp-1">
          {device.name}
        </CardTitle>
      </CardHeader>
      
      <CardContent className="px-4 pb-2 text-sm flex-grow">
        <div className="flex items-center text-muted-foreground text-xs mb-2">
          <MapPin className="h-3.5 w-3.5 mr-1 text-primary/70" />
          <span className="truncate">{device.city}</span>
          
          {device.condition && (
            <>
              <span className="mx-1.5">•</span>
              <Star className="h-3.5 w-3.5 mr-1 text-yellow-500" />
              <span>{device.condition}</span>
            </>
          )}
        </div>
        
        <div 
          className="text-muted-foreground line-clamp-2 mb-3 text-sm"
          dangerouslySetInnerHTML={{ __html: device.description }}
        />
        
        {getMainSpecs().length > 0 && (
          <div className="grid grid-cols-1 gap-1 mb-3">
            {getMainSpecs().map((spec, idx) => (
              <div key={idx} className="flex items-start">
                <Activity className="h-3.5 w-3.5 mr-1.5 mt-0.5 text-primary/70" />
                <span className="text-xs">
                  <span className="font-medium">{spec.name}:</span> {spec.value}
                </span>
              </div>
            ))}
          </div>
        )}
        
        <div className="flex items-center text-xs font-medium text-primary mt-auto">
          <Calendar className="h-3.5 w-3.5 mr-1.5" />
          <span>{device.quantity} {device.quantity > 1 ? 'units' : 'unit'} available</span>
        </div>
      </CardContent>
      
      <CardFooter className="flex flex-col space-y-2 w-full p-4 pt-0">
        <div className="flex gap-2 w-full">
          <Link href={`/devices/${device.id}`} className="flex-1">
            <Button variant="outline" className="w-full flex items-center justify-center">
              <ExternalLink className="h-4 w-4 mr-1.5" />
              View Details
            </Button>
          </Link>
          
          {userRole === "organizer" && (
            <Dialog open={bookingDialogOpen} onOpenChange={setBookingDialogOpen}>
              <DialogTrigger asChild>
                <Button size="default" className="flex-[1.5]">Book Now</Button>
              </DialogTrigger>
              <DialogContent className="max-w-[500px] max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>Book {device.name}</DialogTitle>
                </DialogHeader>
                <BookingRequestForm 
                  device={device} 
                  onSuccess={() => setBookingDialogOpen(false)} 
                />
              </DialogContent>
            </Dialog>
          )}
          
          {userRole === "vendor" && (
            <Link href={`/devices/${device.id}`} className="flex-1">
              <Button variant="secondary" className="w-full flex items-center justify-center">
                <Edit className="h-4 w-4 mr-1.5" />
                Edit
              </Button>
            </Link>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}