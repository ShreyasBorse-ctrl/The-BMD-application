import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Booking, Device } from "@shared/schema";
import { Calendar, MapPin, User, Phone, Mail, Clock, Package } from "lucide-react";
import { format } from "date-fns";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";

// Define Organizer interface
interface Organizer {
  id: number;
  username: string;
  role: string;
  email: string;
  name: string;
  phone: string;
}

interface BookingDetailsDialogProps {
  booking: Booking;
  device: Device | undefined;
  trigger: React.ReactNode;
}

export function BookingDetailsDialog({ booking, device, trigger }: BookingDetailsDialogProps) {
  // Fetch organizer details
  const { data: organizer, isLoading: isLoadingOrganizer } = useQuery<Organizer>({ 
    queryKey: [`/api/users/${booking.organizerId}`],
    enabled: !!booking.organizerId
  });
  
  // Use the actual camp details from the booking object
  // If some fields are undefined (older bookings may not have them),
  // provide sensible defaults
  const campDetails = {
    campName: booking.campName || `Camp at ${booking.city}`,
    campAddress: booking.campAddress || `${booking.city} General Hospital Campus`,
    expectedPatients: booking.expectedPatients || "Not specified",
    additionalRequirements: booking.additionalRequirements || "None specified",
    paymentMode: booking.paymentMode || "Bank Transfer",
    specialInstructions: booking.specialInstructions || "None specified",
    deliveryDate: booking.deliveryDate ? new Date(booking.deliveryDate) : new Date(booking.startDate),
  };

  return (
    <Dialog>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center gap-2">
            Booking Details
            <Badge 
              variant={booking.status === "confirmed" ? "default" : 
                     booking.status === "pending" ? "outline" : "destructive"}
              className={booking.status === "confirmed" ? "bg-green-500 hover:bg-green-600" : ""}
            >
              {booking.status.toUpperCase()}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            Complete details about this camp booking request
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6 my-4">
          {/* Device Information */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
            <h3 className="font-medium text-lg mb-3">Device Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-slate-500">Device</p>
                <p className="font-semibold">{device?.name || "Unknown Device"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Model</p>
                <p>{device?.model || "Not specified"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Quantity</p>
                <p>{booking.quantity} {booking.quantity > 1 ? "units" : "unit"}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Category</p>
                <p>{device?.category || "Not specified"}</p>
              </div>
            </div>
          </div>
          
          {/* Booking Dates */}
          <div className="bg-primary/5 p-4 rounded-lg border border-primary/10">
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-5 w-5 text-primary" />
              <h3 className="font-medium text-lg">Booking Period</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-slate-500">Start Date</p>
                <p>{format(new Date(booking.startDate), "MMMM d, yyyy")}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">End Date</p>
                <p>{format(new Date(booking.endDate), "MMMM d, yyyy")}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Duration</p>
                <p>{Math.round((new Date(booking.endDate).getTime() - new Date(booking.startDate).getTime()) / (1000 * 60 * 60 * 24))} days</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Preferred Delivery</p>
                <p>{format(campDetails.deliveryDate, "MMMM d, yyyy")}</p>
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* Camp Information */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="h-5 w-5 text-primary" />
              <h3 className="font-medium text-lg">Camp Details</h3>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-slate-500">Camp Name</p>
                <p>{campDetails.campName}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Location</p>
                <p>{booking.city}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Address</p>
                <p>{campDetails.campAddress}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Expected Patients</p>
                <p>{campDetails.expectedPatients}</p>
              </div>
            </div>
          </div>
          
          {/* Organizer Information */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-100">
            <div className="flex items-center gap-2 mb-3">
              <User className="h-5 w-5 text-slate-500" />
              <h3 className="font-medium text-lg">Organizer Information</h3>
            </div>
            
            {isLoadingOrganizer ? (
              <div className="space-y-3">
                <Skeleton className="h-5 w-full" />
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-5 w-1/2" />
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-slate-500">Contact Person</p>
                  <p>{organizer?.name || "Not available"}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-500">Role</p>
                  <p className="capitalize">{organizer?.role || "Organizer"}</p>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 mr-2 text-slate-400" />
                  <p>{organizer?.phone || "Contact not available"}</p>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 mr-2 text-slate-400" />
                  <p>{organizer?.email || "Email not available"}</p>
                </div>
                <div className="flex items-center col-span-2">
                  <Clock className="h-4 w-4 mr-2 text-slate-400" />
                  <p>Requested on {format(new Date(booking.startDate), "MMMM d, yyyy")}</p>
                </div>
              </div>
            )}
          </div>
          
          {/* Additional Requirements */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Package className="h-5 w-5 text-primary" />
              <h3 className="font-medium text-lg">Additional Requirements</h3>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-slate-500">Requirements</p>
                <p className="bg-slate-50 p-3 rounded border border-slate-100 mt-1">
                  {campDetails.additionalRequirements || "No specific requirements"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Special Instructions</p>
                <p className="bg-slate-50 p-3 rounded border border-slate-100 mt-1">
                  {campDetails.specialInstructions || "No special instructions"}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-slate-500">Payment Mode</p>
                <p>{campDetails.paymentMode}</p>
              </div>
            </div>
          </div>
        </div>
        
        <DialogFooter>
          <DialogTrigger asChild>
            <Button variant="outline" type="button">Close</Button>
          </DialogTrigger>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}