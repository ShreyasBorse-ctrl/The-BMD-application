import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema, type Device, type InsertBooking } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { ColorCodedCalendar } from "./ColorCodedCalendar";
import { AlertCircle, Calendar, MapPin, Users, Package, Clipboard, Mail, Phone } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import { useAuth } from "@/hooks/use-auth";
import { z } from "zod";

interface BookingRequestFormProps {
  device: Device;
  onSuccess?: () => void;
}

// Extend the insertBookingSchema with additional fields for the improved form
const campRequestSchema = insertBookingSchema.extend({
  // Camp details
  campName: z.string().min(1, "Camp name is required"),
  campAddress: z.string().min(1, "Camp address is required"),
  expectedPatients: z.string().min(1, "Number of patients is required"),
  
  // Payment and delivery details
  additionalRequirements: z.string().optional(),
  deliveryDate: z.string().optional(),
  paymentMode: z.enum(["Bank Transfer", "Cash", "Online Payment"]).default("Bank Transfer"),
  specialInstructions: z.string().optional(),
});

type CampRequestFormData = z.infer<typeof campRequestSchema>;

export function BookingRequestForm({ device, onSuccess }: BookingRequestFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [hasConflict, setHasConflict] = useState(false);
  const { user } = useAuth();

  const form = useForm<CampRequestFormData>({
    resolver: zodResolver(campRequestSchema),
    defaultValues: {
      deviceId: device.id,
      city: device.city,
      quantity: 1, // Default to 1 unit
      campName: "",
      campAddress: "",
      expectedPatients: "",
      additionalRequirements: "",
      deliveryDate: "",
      paymentMode: "Bank Transfer",
      specialInstructions: "",
    },
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: CampRequestFormData) => {
      // Include all camp details in the booking data
      const bookingData = {
        deviceId: data.deviceId,
        startDate: data.startDate,
        endDate: data.endDate,
        city: data.city,
        quantity: data.quantity,
        // New camp details fields
        campName: data.campName,
        campAddress: data.campAddress,
        expectedPatients: data.expectedPatients,
        additionalRequirements: data.additionalRequirements || "",
        deliveryDate: data.deliveryDate,
        paymentMode: data.paymentMode,
        specialInstructions: data.specialInstructions || ""
      };
      
      const res = await apiRequest("POST", "/api/bookings", bookingData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Camp request sent successfully",
        description: "The vendor will review your request shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      onSuccess?.();
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send camp request",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  function onSubmit(data: CampRequestFormData) {
    if (hasConflict) {
      toast({
        title: "Booking quantity conflict",
        description: "The requested quantity is not available for the selected dates. Please try reducing the quantity or selecting different dates.",
        variant: "destructive",
      });
      return;
    }
    
    bookingMutation.mutate(data);
  }

  const startDate = form.watch("startDate") ? new Date(form.watch("startDate")) : undefined;
  const endDate = form.watch("endDate") ? new Date(form.watch("endDate")) : undefined;
  
  const formatDateRange = () => {
    if (startDate && endDate) {
      return `${format(startDate, "MMMM d, yyyy")} to ${format(endDate, "MMMM d, yyyy")}`;
    }
    return "Please select dates";
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 bg-white p-6 rounded-xl shadow-md">
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-slate-800 mb-2">Camp Request Form</h2>
          <p className="text-slate-600">Please provide the details below to submit your camp request</p>
        </div>
        
        {/* Calendar Section */}
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-slate-700">Select Dates</h3>
          </div>
          
          <ColorCodedCalendar
            device={device}
            mode="range"
            selectedStartDate={startDate}
            selectedEndDate={endDate}
            onStartDateSelect={(date: Date | undefined) => {
              form.setValue("startDate", date?.toISOString() || "");
              if (date && endDate && date > endDate) {
                form.setValue("endDate", "");
              }
            }}
            onEndDateSelect={(date: Date | undefined) => {
              form.setValue("endDate", date?.toISOString() || "");
            }}
            setHasConflict={setHasConflict}
            requestedQuantity={Number(form.watch("quantity") || 1)}
          />

          {hasConflict && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Booking Conflict</AlertTitle>
              <AlertDescription>
                The requested quantity is not available for the selected dates. Please try reducing the quantity or selecting different dates.
              </AlertDescription>
            </Alert>
          )}
        </div>
        
        <Separator className="my-6" />
        
        {/* Basic Details Section */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <MapPin className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-slate-700">Basic Details</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Selected Dates */}
            <FormItem>
              <FormLabel>Selected Dates</FormLabel>
              <div className="h-10 px-3 py-2 rounded-md border border-input bg-gray-50 text-sm">
                {formatDateRange()}
              </div>
            </FormItem>
            
            {/* City */}
            <FormField
              control={form.control}
              name="city"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>City (Fixed)</FormLabel>
                  <FormControl>
                    <Input readOnly className="bg-gray-50 cursor-not-allowed" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Device Name */}
            <FormItem>
              <FormLabel>Device Name</FormLabel>
              <div className="h-10 px-3 py-2 rounded-md border border-input bg-gray-50 text-sm">
                {device.name}
              </div>
            </FormItem>
            
            {/* Quantity */}
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity Required</FormLabel>
                  <FormControl>
                    <Input 
                      type="number" 
                      min={1} 
                      max={device.quantity} 
                      {...field}
                      onChange={(e) => {
                        // Ensure number is within valid range
                        const value = parseInt(e.target.value);
                        let newValue = value;
                        
                        if (isNaN(value) || value < 1) {
                          newValue = 1;
                          field.onChange(newValue);
                        } else if (value > device.quantity) {
                          newValue = device.quantity;
                          field.onChange(newValue);
                        } else {
                          field.onChange(value);
                          newValue = value;
                        }
                        
                        // Re-check conflict when quantity changes and dates are selected
                        if (startDate && endDate) {
                          // This will cause ColorCodedCalendar to re-render with the new quantity
                          // and update conflict status accordingly
                          setTimeout(() => {
                            form.trigger(["startDate", "endDate"]);
                          }, 100);
                        }
                      }}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <Separator className="my-6" />
        
        {/* Camp Details Section */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <Clipboard className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-slate-700">Camp Details</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="campName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Camp Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter the name of your camp" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="campAddress"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Camp Address</FormLabel>
                  <FormControl>
                    <Input placeholder="Enter the full address" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="expectedPatients"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Expected Number of Patients</FormLabel>
                  <FormControl>
                    <Input placeholder="Estimated patients per day" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="deliveryDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Preferred Delivery Date</FormLabel>
                  <FormControl>
                    <Input type="date" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <Separator className="my-6" />
        
        {/* Organizer Details Section */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <Users className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-slate-700">Organizer Details</h3>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Organizer Name - Auto-filled from user account */}
            <FormItem>
              <FormLabel>Organizer Name</FormLabel>
              <div className="h-10 px-3 py-2 rounded-md border border-input bg-gray-50 text-sm">
                {user?.name || "Loading..."}
              </div>
            </FormItem>
            
            {/* Email - Auto-filled from user account */}
            <FormItem>
              <FormLabel>Email</FormLabel>
              <div className="h-10 px-3 py-2 rounded-md border border-input bg-gray-50 text-sm flex items-center">
                <Mail className="h-4 w-4 mr-2 text-gray-400" />
                {user?.email || "Loading..."}
              </div>
            </FormItem>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Phone Number - Auto-filled from user account */}
            <FormItem>
              <FormLabel>Phone</FormLabel>
              <div className="h-10 px-3 py-2 rounded-md border border-input bg-gray-50 text-sm flex items-center">
                <Phone className="h-4 w-4 mr-2 text-gray-400" />
                {user?.phone || "Loading..."}
              </div>
            </FormItem>
            
            {/* Payment Mode */}
            <FormField
              control={form.control}
              name="paymentMode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Payment Mode</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a payment method" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="Bank Transfer">Bank Transfer</SelectItem>
                      <SelectItem value="Cash">Cash</SelectItem>
                      <SelectItem value="Online Payment">Online Payment</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
        </div>
        
        <Separator className="my-6" />
        
        {/* Additional Requirements Section */}
        <div className="space-y-6">
          <div className="flex items-center gap-2 mb-2">
            <Package className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold text-slate-700">Additional Requirements</h3>
          </div>
          
          <FormField
            control={form.control}
            name="additionalRequirements"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Additional Requirements</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Enter any additional equipment, setup or requirements" 
                    className="resize-none" 
                    rows={3}
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="specialInstructions"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Special Instructions</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Any specific instructions for the vendor" 
                    className="resize-none" 
                    rows={3}
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button 
          type="submit" 
          className="w-full mt-6 bg-primary hover:bg-primary/90 text-white py-6 text-base"
          disabled={bookingMutation.isPending || hasConflict || !startDate || !endDate}
        >
          {bookingMutation.isPending ? "Sending camp request..." : "Submit Camp Request"}
        </Button>
        
        <p className="text-sm text-slate-500 mt-2 text-center">
          By submitting this form, you agree to our terms and conditions.
        </p>
      </form>
    </Form>
  );
}