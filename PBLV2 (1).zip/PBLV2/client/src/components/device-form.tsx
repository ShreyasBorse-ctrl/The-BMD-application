import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertDeviceSchema, type InsertDevice } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent } from "@/components/ui/card";
import { useState } from "react";
import { Trash2 } from "lucide-react";

const categories = [
  "Portable Ultrasound (QUS) – Heel/Wrist Scanner",
  "Peripheral DEXA (pDEXA) – Wrist/Forearm Scanner",
  "Handheld BMD Device",
  "Semi-Portable DEXA – Tabletop Scanner",
  "Peripheral QCT (pQCT) – Forearm/Tibia Scanner",
  "Full-Body DEXA (DXA) – Clinical Use",
] as const;

const cities = [
  "Mumbai",
  "Delhi",
  "Bangalore",
  "Chennai",
  "Kolkata",
  "Hyderabad",
  "Ahmedabad",
  "Pune",
  "Surat",
  "Jaipur",
  "Lucknow",
  "Kanpur",
  "Nagpur",
  "Indore",
  "Patna",
  "Vadodara",
  "Ghaziabad",
  "Ludhiana",
  "Coimbatore",
  "Agra",
  "Madurai",
  "Nashik",
  "Faridabad",
  "Meerut",
  "Rajkot",
  "Howrah",
  "Vijayawada",
  "Chandigarh",
  "Bhopal",
  "Visakhapatnam",
  "Kochi",
  "Noida",
  "Bhubaneswar",
  "Mysuru",
  "Thane",
  "Udaipur",
] as const;

// Define our specification interface
interface Specification {
  name: string;
  value: string;
}

export function DeviceForm() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [specs, setSpecs] = useState<Specification[]>([]);
  const [richDescription, setRichDescription] = useState('');
  const [activeTab, setActiveTab] = useState('basic');

  const form = useForm<InsertDevice & { brand?: string, model?: string }>({
    resolver: zodResolver(insertDeviceSchema),
    defaultValues: {
      name: "",
      brand: "",
      model: "",
      description: "",
      category: "Portable Ultrasound (QUS) – Heel/Wrist Scanner",
      pricePerDay: 0,
      quantity: 1,
      city: "Mumbai",
      condition: "New",
      images: [],
    },
  });

  // Add a specification field
  const addSpec = () => {
    setSpecs([...specs, { name: "", value: "" }]);
  };

  // Update a specification
  const updateSpec = (index: number, field: 'name' | 'value', value: string) => {
    const newSpecs = [...specs];
    newSpecs[index][field] = value;
    setSpecs(newSpecs);
  };

  // Remove a specification
  const removeSpec = (index: number) => {
    const newSpecs = [...specs];
    newSpecs.splice(index, 1);
    setSpecs(newSpecs);
  };

  async function onSubmit(values: InsertDevice & { brand?: string, model?: string }) {
    try {
      // Include specifications and rich description in submission
      const deviceData = {
        ...values,
        // Store specifications as a JSON string in the specifications array
        specifications: specs.map(spec => JSON.stringify(spec)),
        // If using rich description, replace the regular description
        description: richDescription || values.description,
      };

      await apiRequest("POST", "/api/devices", deviceData);
      queryClient.invalidateQueries({ queryKey: ["/api/devices"] });
      toast({
        title: "Success",
        description: "Device listed successfully",
      });
      form.reset();
      setSpecs([]);
      setRichDescription('');
    } catch (error) {
      toast({
        title: "Error",
        description:
          error instanceof Error ? error.message : "Failed to list device",
        variant: "destructive",
      });
    }
  }

  return (
    <div className="container max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-6">Add New Device</h2>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="basic">Basic Info</TabsTrigger>
          <TabsTrigger value="specs">Specifications</TabsTrigger>
          <TabsTrigger value="description">Description</TabsTrigger>
          <TabsTrigger value="images">Images</TabsTrigger>
          <TabsTrigger value="availability">Availability</TabsTrigger>
        </TabsList>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Basic Info Tab */}
            <TabsContent value="basic" className="space-y-6 pt-4">
              <div className="grid grid-cols-1 gap-6">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Device Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter device name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="brand"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Brand</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., OsteoSys, GE Healthcare" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="model"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Model</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., SONOST 3000" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {categories.map((category) => (
                            <SelectItem key={category} value={category}>
                              {category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="pricePerDay"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price per Day (₹)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="Enter price in ₹"
                          {...field}
                          onChange={(e) => field.onChange(Number(e.target.value))}
                        />
                      </FormControl>
                      <FormDescription>
                        This is the daily rental price for this device
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="city"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>City</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select a city" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {cities.map((city) => (
                              <SelectItem key={city} value={city}>
                                {city}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="condition"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Device Condition</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select condition" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="New">New</SelectItem>
                            <SelectItem value="Refurbished">Refurbished</SelectItem>
                            <SelectItem value="Used - Good">Used - Good</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
            </TabsContent>
            
            {/* Specifications Tab */}
            <TabsContent value="specs" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Specifications</h3>
                  <div className="space-y-4">
                    {specs.map((spec, idx) => (
                      <div key={idx} className="flex space-x-2">
                        <Input
                          placeholder="Specification Name (e.g., Weight)"
                          value={spec.name}
                          onChange={(e) => updateSpec(idx, 'name', e.target.value)}
                          className="flex-1"
                        />
                        <Input
                          placeholder="Value (e.g., 11 Kg)"
                          value={spec.value}
                          onChange={(e) => updateSpec(idx, 'value', e.target.value)}
                          className="flex-1"
                        />
                        <Button 
                          type="button" 
                          variant="destructive" 
                          size="icon"
                          onClick={() => removeSpec(idx)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    
                    <Button
                      type="button"
                      variant="outline"
                      onClick={addSpec}
                      className="mt-2"
                    >
                      + Add Specification
                    </Button>
                    
                    <FormDescription className="mt-2">
                      Add specifications like Weight, Power Supply, Measurement Site, etc.
                    </FormDescription>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Description Tab */}
            <TabsContent value="description" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Description</h3>
                  
                  {/* Rich text editor */}
                  <div>
                    <FormLabel>Device Description</FormLabel>
                    <div className="mt-2">
                      <ReactQuill
                        theme="snow"
                        value={richDescription}
                        onChange={(value) => {
                          setRichDescription(value);
                          // Also update the form field to ensure validation
                          const plainText = value.replace(/<[^>]*>/g, '').trim();
                          form.setValue('description', plainText);
                        }}
                        className="bg-card"
                        modules={{
                          toolbar: [
                            [{ 'header': [1, 2, 3, false] }],
                            ['bold', 'italic', 'underline', 'strike'],
                            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                            ['link'],
                            ['clean']
                          ]
                        }}
                      />
                      <FormDescription className="mt-2">
                        Use this rich text editor to format your description with headings, bold text, lists, etc.
                      </FormDescription>
                      <FormMessage>{form.formState.errors.description?.message}</FormMessage>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Images Tab */}
            <TabsContent value="images" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Images</h3>
                  
                  <FormField
                    control={form.control}
                    name="images"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Upload Images</FormLabel>
                        <FormControl>
                          <div className="space-y-4">
                            <Input
                              type="file"
                              accept="image/*"
                              multiple
                              key="file-input" 
                              onChange={(e) => {
                                const files = e.target.files;
                                if (files) {
                                  // Convert File objects to data URLs
                                  Promise.all(
                                    Array.from(files).map((file) => {
                                      return new Promise<string>((resolve) => {
                                        const reader = new FileReader();
                                        reader.onloadend = () => {
                                          resolve(reader.result as string);
                                        };
                                        reader.readAsDataURL(file);
                                      });
                                    }),
                                  ).then((dataUrls) => {
                                    field.onChange(dataUrls);
                                  });
                                }
                              }}
                            />
                            
                            {/* Display selected image names */}
                            {field.value && Array.isArray(field.value) && field.value.length > 0 && (
                              <div className="mt-2 p-2 border rounded bg-muted">
                                <p className="font-medium text-sm">Selected images: {field.value.length}</p>
                                <ul className="mt-1 text-xs text-muted-foreground">
                                  {field.value.map((image, index) => (
                                    <li key={index} className="truncate">
                                      {typeof image === 'string' && image.startsWith('data:image/') ? (
                                        <>Image {index + 1}</>
                                      ) : (
                                        image.toString().substring(0, 30) + '...'
                                      )}
                                    </li>
                                  )).slice(0, 3)}
                                  {field.value.length > 3 && (
                                    <li>...and {field.value.length - 3} more</li>
                                  )}
                                </ul>
                              </div>
                            )}
                          </div>
                        </FormControl>
                        <FormDescription>
                          Upload multiple images of your device from different angles. 
                          We recommend front, side, and detail views.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Availability Tab */}
            <TabsContent value="availability" className="space-y-6 pt-4">
              <Card>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-medium mb-4">Device Availability</h3>
                  <p className="text-muted-foreground">
                    In this section, you can set the overall availability of your device.
                    Please note that individual booking dates will be managed after your device is listed.
                  </p>
                  
                  <div className="flex space-x-2 items-center mt-4">
                    <FormField
                      control={form.control}
                      name="quantity"
                      render={({ field }) => (
                        <FormItem className="flex-1">
                          <FormLabel>Total Units Available</FormLabel>
                          <FormControl>
                            <Input
                              type="number"
                              min="1"
                              placeholder="Number of units"
                              {...field}
                              onChange={(e) => field.onChange(Number(e.target.value))}
                            />
                          </FormControl>
                          <FormDescription>
                            Enter the total number of units you have available for booking
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            {/* Submit Button - Present on all tabs */}
            <div className="flex justify-between items-center mt-6 pt-4 border-t">
              <div className="flex space-x-2">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    const currentIndex = ['basic', 'specs', 'description', 'images', 'availability'].indexOf(activeTab);
                    if (currentIndex > 0) {
                      setActiveTab(['basic', 'specs', 'description', 'images', 'availability'][currentIndex - 1]);
                    }
                  }}
                  disabled={activeTab === 'basic'}
                >
                  Previous
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => {
                    const currentIndex = ['basic', 'specs', 'description', 'images', 'availability'].indexOf(activeTab);
                    if (currentIndex < 4) {
                      setActiveTab(['basic', 'specs', 'description', 'images', 'availability'][currentIndex + 1]);
                    }
                  }}
                  disabled={activeTab === 'availability'}
                >
                  Next
                </Button>
              </div>
              <Button type="submit">List Device</Button>
            </div>
          </form>
        </Form>
      </Tabs>
    </div>
  );
}