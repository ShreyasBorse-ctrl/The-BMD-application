import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { Menu, X, User, Box, LogOut, Settings, Home, Calendar, Tag, HelpCircle, Phone, Info, ShieldAlert } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

export default function Navbar() {
  const { user, logoutMutation } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const isMobile = useIsMobile();
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const closeMenu = () => {
    setIsOpen(false);
  };

  // Common links for all users
  const commonLinks = [
    { label: "Home", path: "/", icon: <Home className="h-4 w-4 mr-2" /> },
  ];

  // User-specific links based on role
  const userRoleLinks = !user ? [] : (
    user.role === "admin" ?
    [
      { label: "Admin Dashboard", path: "/admin-dashboard", icon: <ShieldAlert className="h-4 w-4 mr-2" /> },
    ] :
    user.role === "vendor" ? 
    [
      { label: "Vendor Dashboard", path: "/vendor-dashboard", icon: <Box className="h-4 w-4 mr-2" /> },
      { label: "Earnings", path: "/vendor-earnings", icon: <Tag className="h-4 w-4 mr-2" /> },
    ] : 
    [
      { label: "My Bookings", path: "/organizer-dashboard", icon: <Calendar className="h-4 w-4 mr-2" /> },
    ]
  );

  // Additional links
  const additionalLinks = [
    { label: "About Us", path: "/about", icon: <Info className="h-4 w-4 mr-2" /> },
    { label: "FAQs", path: "/faqs", icon: <HelpCircle className="h-4 w-4 mr-2" /> },
    { label: "Contact", path: "/contact", icon: <Phone className="h-4 w-4 mr-2" /> },
  ];

  return (
    <nav className="sticky top-0 bg-white border-b border-slate-200 z-50 shadow-sm">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo and Brand */}
          <div className="flex items-center">
            <Link href="/">
              <div className="flex items-center cursor-pointer">
                <span className="text-2xl font-bold text-primary">BMD</span>
                <span className="text-2xl font-semibold ml-1">Camp</span>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation Links */}
          {!isMobile && (
            <div className="hidden md:flex items-center space-x-4">
              {commonLinks.map((link) => (
                <Link key={link.path} href={link.path}>
                  <div className={cn(
                    "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer",
                    isActive(link.path) ? 
                      "bg-primary/10 text-primary" : 
                      "text-gray-700 hover:text-primary hover:bg-primary/5"
                  )}>
                    {link.icon}
                    {link.label}
                  </div>
                </Link>
              ))}
              
              {/* User Role Specific Links */}
              {user && userRoleLinks.map((link, index) => (
                <Link key={`${link.path}-${index}`} href={link.path}>
                  <div className={cn(
                    "flex items-center px-3 py-2 rounded-md text-sm font-medium transition-colors cursor-pointer",
                    isActive(link.path) ? 
                      "bg-primary/10 text-primary" : 
                      "text-gray-700 hover:text-primary hover:bg-primary/5"
                  )}>
                    {link.icon}
                    {link.label}
                  </div>
                </Link>
              ))}

              {/* More Dropdown */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm" className="px-3 py-2 text-sm font-medium">
                    <span className="mr-1">More</span>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 opacity-50">
                      <path d="M2 4L6 8L10 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-[180px]">
                  {additionalLinks.map((link) => (
                    <Link key={link.path} href={link.path}>
                      <DropdownMenuItem className="cursor-pointer">
                        {link.icon}
                        <span>{link.label}</span>
                      </DropdownMenuItem>
                    </Link>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          )}

          {/* User Menu */}
          <div className="flex items-center md:space-x-4">
            {/* User Avatar or Login/Register */}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="ghost" 
                    className="relative h-8 rounded-full flex items-center gap-2 pl-2 pr-4 hover:bg-primary/5"
                  >
                    <div className="flex items-center justify-center h-7 w-7 rounded-full bg-primary/10 text-primary">
                      {user.username.charAt(0).toUpperCase()}
                    </div>
                    <span className="text-sm font-medium hidden md:inline-block">
                      {user.name || user.username}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">{user.name || user.username}</p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user.email}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground capitalize">
                        {user.role}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuGroup>
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    {user.role === "admin" && (
                      <Link href="/admin-dashboard">
                        <DropdownMenuItem className="cursor-pointer">
                          <ShieldAlert className="mr-2 h-4 w-4" />
                          <span>Admin Dashboard</span>
                        </DropdownMenuItem>
                      </Link>
                    )}
                    {user.role === "vendor" && (
                      <Link href="/vendor-dashboard">
                        <DropdownMenuItem className="cursor-pointer">
                          <Box className="mr-2 h-4 w-4" />
                          <span>Vendor Dashboard</span>
                        </DropdownMenuItem>
                      </Link>
                    )}
                    {user.role === "organizer" && (
                      <Link href="/organizer-dashboard">
                        <DropdownMenuItem className="cursor-pointer">
                          <Calendar className="mr-2 h-4 w-4" />
                          <span>My Bookings</span>
                        </DropdownMenuItem>
                      </Link>
                    )}
                  </DropdownMenuGroup>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout} className="cursor-pointer text-red-600">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Log out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : location !== "/auth" ? (
              <div className="flex space-x-2">
                <Link href="/auth">
                  <Button variant="outline" size="sm">Login</Button>
                </Link>
                <Link href="/auth">
                  <Button size="sm">Register</Button>
                </Link>
              </div>
            ) : null}

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsOpen(!isOpen)}
                className="focus:ring-0"
              >
                {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white py-2 px-4 border-t border-slate-200 shadow-inner">
          <div className="space-y-1">
            {commonLinks.map((link) => (
              <Link key={link.path} href={link.path}>
                <div 
                  className={cn(
                    "flex items-center px-3 py-3 rounded-md text-base font-medium transition-colors cursor-pointer",
                    isActive(link.path) ? 
                      "bg-primary/10 text-primary" : 
                      "text-gray-700 hover:text-primary hover:bg-primary/5"
                  )}
                  onClick={closeMenu}
                >
                  {link.icon}
                  {link.label}
                </div>
              </Link>
            ))}
            
            {/* User Role Specific Links */}
            {user && (
              <>
                <div className="pt-2 pb-1">
                  <p className="px-3 text-xs uppercase font-semibold text-gray-500">
                    {user.role === "admin" 
                      ? "Admin" 
                      : user.role === "vendor" 
                        ? "Vendor" 
                        : "Organizer"} Menu
                  </p>
                </div>
                {userRoleLinks.map((link, index) => (
                  <Link key={`mobile-${link.path}-${index}`} href={link.path}>
                    <div 
                      className={cn(
                        "flex items-center px-3 py-3 rounded-md text-base font-medium transition-colors cursor-pointer",
                        isActive(link.path) ? 
                          "bg-primary/10 text-primary" : 
                          "text-gray-700 hover:text-primary hover:bg-primary/5"
                      )}
                      onClick={closeMenu}
                    >
                      {link.icon}
                      {link.label}
                    </div>
                  </Link>
                ))}
              </>
            )}
            
            {/* Additional Links */}
            <div className="pt-2 pb-1">
              <p className="px-3 text-xs uppercase font-semibold text-gray-500">
                More
              </p>
            </div>
            {additionalLinks.map((link, index) => (
              <Link key={`more-${link.path}-${index}`} href={link.path}>
                <div 
                  className={cn(
                    "flex items-center px-3 py-3 rounded-md text-base font-medium transition-colors cursor-pointer",
                    isActive(link.path) ? 
                      "bg-primary/10 text-primary" : 
                      "text-gray-700 hover:text-primary hover:bg-primary/5"
                  )}
                  onClick={closeMenu}
                >
                  {link.icon}
                  {link.label}
                </div>
              </Link>
            ))}
            
            {/* Logout Button */}
            {user && (
              <div className="pt-2">
                <button
                  className="flex w-full items-center px-3 py-3 rounded-md text-base font-medium text-red-600 hover:bg-red-50"
                  onClick={() => {
                    handleLogout();
                    closeMenu();
                  }}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Log out
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}