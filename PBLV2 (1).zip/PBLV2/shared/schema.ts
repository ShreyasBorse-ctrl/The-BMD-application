/**
 * Shared schema definitions
 * Defines database tables structure, types, and validation schemas
 * Used by both client and server for type safety and data validation
 */

import { pgTable, text, serial, integer, boolean, timestamp, varchar, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role", { enum: ["vendor", "organizer", "admin"] }).notNull(),
  isApproved: boolean("is_approved").notNull().default(true),
  email: text("email").notNull(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
});

export const devices = pgTable("devices", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull(),
  name: text("name").notNull(),
  brand: text("brand"),
  model: text("model"),
  description: text("description").notNull(),
  category: text("category", { 
    enum: [
      "Portable Ultrasound (QUS) – Heel/Wrist Scanner",
      "Peripheral DEXA (pDEXA) – Wrist/Forearm Scanner",
      "Handheld BMD Device",
      "Semi-Portable DEXA – Tabletop Scanner",
      "Peripheral QCT (pQCT) – Forearm/Tibia Scanner",
      "Full-Body DEXA (DXA) – Clinical Use"
    ] 
  }).notNull(),
  pricePerDay: integer("price_per_day").notNull(),
  quantity: integer("quantity").notNull().default(1),
  city: text("city").notNull(),
  condition: text("condition", { enum: ["New", "Refurbished", "Used - Good"] }).notNull(),
  specifications: text("specifications").array(), // Store as JSON string array of {name, value} objects
  images: text("images").array().notNull(),
  available: boolean("available").notNull().default(true),
  isApproved: boolean("is_approved").notNull().default(false),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  deviceId: integer("device_id").notNull(),
  organizerId: integer("organizer_id").notNull(),
  startDate: timestamp("start_date").notNull(),
  endDate: timestamp("end_date").notNull(),
  status: text("status", { enum: ["pending", "confirmed", "completed", "cancelled"] }).notNull(),
  city: text("city").notNull(),
  quantity: integer("quantity").notNull().default(1),
  // Additional camp details
  campName: text("camp_name"),
  campAddress: text("camp_address"),
  expectedPatients: text("expected_patients"),
  additionalRequirements: text("additional_requirements"),
  deliveryDate: text("delivery_date"),
  paymentMode: text("payment_mode"),
  specialInstructions: text("special_instructions"),
});

export const sessions = pgTable("session", {
  sid: varchar("sid").primaryKey(),
  sess: json("sess").notNull(),
  expire: timestamp("expire").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  role: true,
  email: true,
  name: true,
  phone: true,
});

export const insertDeviceSchema = createInsertSchema(devices)
  .omit({ 
    id: true,
    available: true,
    vendorId: true,
    isApproved: true
  })
  .extend({
    pricePerDay: z.number().min(1, "Price must be greater than 0"),
    quantity: z.number().min(1, "Quantity must be at least 1"),
  });

export const insertBookingSchema = createInsertSchema(bookings)
  .omit({ 
    id: true,
    organizerId: true,
    status: true 
  })
  .extend({
    startDate: z.string().or(z.date()),
    endDate: z.string().or(z.date()),
    city: z.string().min(1, "City is required"),
    quantity: z.number().min(1, "Quantity must be at least 1").default(1),
    // Add validation for new fields
    campName: z.string().optional(),
    campAddress: z.string().optional(),
    expectedPatients: z.string().optional(),
    additionalRequirements: z.string().optional(),
    deliveryDate: z.string().optional(),
    paymentMode: z.string().optional(),
    specialInstructions: z.string().optional(),
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Device = typeof devices.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type InsertDevice = z.infer<typeof insertDeviceSchema>;
export type InsertBooking = z.infer<typeof insertBookingSchema>;